scale.dat=read.csv("BCWSC_AgedSpawners.csv")
#trim out un-assigned ages (age 0)
good.scale.dat=scale.dat[scale.dat$ReadAge>0,]
min.age=min(good.scale.dat$ReadAge) #2
max.age=max(good.scale.dat$ReadAge) #4
num.ages=max.age-min.age+1 #3     ###If any of these change, need to recode!

options(scipen=9999) #suppress scientific notation


valid.mat=as.matrix(read.csv("ValidationMatrix.csv",header=FALSE))

return.years=c(min(good.scale.dat$ReturnYear):max(good.scale.dat$ReturnYear)) #realizing this will add a row with NAs - but we want NAs to factor into inability to estimate age structure for some brood years as appropriate later

raw.age.structure=array(NA,c(length(return.years),(1+num.ages)))
raw.age.structure[,1]=return.years

adj.age.structure=raw.age.structure

for (year.step in 1:(length(return.years)))
{#loop over return years
	raw.2s=sum(good.scale.dat$ReadAge[good.scale.dat$ReturnYear==return.years[year.step]]==2)
	raw.3s=sum(good.scale.dat$ReadAge[good.scale.dat$ReturnYear==return.years[year.step]]==3)
	raw.4s=sum(good.scale.dat$ReadAge[good.scale.dat$ReturnYear==return.years[year.step]]==4)
	raw.N=raw.2s+raw.3s+raw.4s
	raw.age.structure[year.step,2:4]=c(raw.2s,raw.3s,raw.4s)/raw.N
	read.ages=c(raw.2s,raw.3s,raw.4s)
	source("KimuraChikuni.r")
	adj.age.structure[year.step,2:4]=p.hat.final	
}#loop over return years

write(c("ReturnYear","Prop2","Prop3","Prop4"),file="ReturnYrRawAgeStructure.csv",ncolumns=4,sep=",")
write(t(raw.age.structure),file="ReturnYrRawAgeStructure.csv",ncolumns=4,sep=",",append=TRUE)

write(c("ReturnYear","Prop2adj","Prop3adj","Prop4adj"),file="ReturnYrAdjAgeStructure.csv",ncolumns=4,sep=",")
write(t(adj.age.structure),file="ReturnYrAdjAgeStructure.csv",ncolumns=4,sep=",",append=TRUE)

escapement.dat=read.csv("BCWSCescapement.csv") #from Azat 2022, used carcass survey numbers, note that these include pre-spawn mortalities, which seems to be what we want -- run size as opposed to spawners per se
escapements.of.interest=escapement.dat$Escapement[escapement.dat$ReturnYear<2019]


adj.runsize=adj.age.structure #to get right dimensions and have year already filled in
for (year.step in 1:length(return.years))
{#loop over years	
	for (age in 2:4)
	{#loop over	ages
		adj.runsize[year.step,age]=escapements.of.interest[year.step]*adj.age.structure[year.step,age]
	}#loop over ages
}#loop over years
write(c("ReturnYear","Age2runsize","Age3runsize","Age4runsize"),file="ReturnYrEscAtAge.csv",ncolumns=4,sep=",")
write(t(adj.runsize),file="ReturnYrEscAtAge.csv",ncolumns=4,sep=",",append=TRUE)


brood.years=c(2006:2016) #earliest and latest brood years for which any age 2-4 could be observed in available data
brood.year.returns=array(NA,c(length(brood.years),4))
brood.year.returns[,1]=brood.years
brood.year.returns[3:11,2]=adj.runsize[,2]
brood.year.returns[2:10,3]=adj.runsize[,3]
brood.year.returns[1:9,4]=adj.runsize[,4]
write(c("BroodYear","Age2runsize","Age3runsize","Age4runsize"),file="BroodYrEscAtAge.csv",ncolumns=4,sep=",")
write(t(brood.year.returns),file="BroodYrEscAtAge.csv",ncolumns=4,sep=",",append=TRUE)

M=0.2 #assume 20% annual natural mortality for later life in ocean
SI.dat=read.csv("SItable.csv")

Mat3s=array(NA,c(length(brood.years),2))
for (brood.step in 1:length(brood.years))
{#loop over brood years
	brood.yr=brood.years[brood.step]
	S3=brood.year.returns[brood.year.returns[,1]==brood.yr,3]
	S4=brood.year.returns[brood.year.returns[,1]==brood.yr,4]
	SI.oh=SI.dat$SI.oh[SI.dat$Year==brood.yr+3]
	N3=S3+S4/((1-M)*(1-SI.oh))
	mat3=S3/N3
	Mat3s[brood.step,]=c(brood.yr,mat3)
}#loop over brood years
write(c("BroodYear","Age3MatRate"),file="BroodYrMat3.csv",ncolumns=2,sep=",")
write(t(Mat3s),file="BroodYrMat3.csv",ncolumns=2,sep=",",append=TRUE)








raw.runsize=raw.age.structure #to get right dimensions and have year already filled in
for (year.step in 1:length(return.years))
{#loop over years	
	for (age in 2:4)
	{#loop over	ages
		raw.runsize[year.step,age]=escapements.of.interest[year.step]*raw.age.structure[year.step,age]
	}#loop over ages
}#loop over years
write(c("ReturnYear","RawAge2runsize","RawAge3runsize","RawAge4runsize"),file="RawReturnYrEscAtAge.csv",ncolumns=4,sep=",")
write(t(raw.runsize),file="RawReturnYrEscAtAge.csv",ncolumns=4,sep=",",append=TRUE)

raw.brood.year.returns=array(NA,c(length(brood.years),4))
raw.brood.year.returns[,1]=brood.years
raw.brood.year.returns[3:11,2]=raw.runsize[,2]
raw.brood.year.returns[2:10,3]=raw.runsize[,3]
raw.brood.year.returns[1:9,4]=raw.runsize[,4]
write(c("BroodYear","RawAge2runsize","RawAge3runsize","RawAge4runsize"),file="RawBroodYrEscAtAge.csv",ncolumns=4,sep=",")
write(t(raw.brood.year.returns),file="RawBroodYrEscAtAge.csv",ncolumns=4,sep=",",append=TRUE)

RawMat3s=array(NA,c(length(brood.years),2))
for (brood.step in 1:length(brood.years))
{#loop over brood years
	brood.yr=brood.years[brood.step]
	S3=raw.brood.year.returns[brood.year.returns[,1]==brood.yr,3]
	S4=raw.brood.year.returns[brood.year.returns[,1]==brood.yr,4]
	SI.oh=SI.dat$SI.oh[SI.dat$Year==brood.yr+3]
	N3=S3+S4/((1-M)*(1-SI.oh))
	mat3=S3/N3
	RawMat3s[brood.step,]=c(brood.yr,mat3)
}#loop over brood years
write(c("BroodYear","RawAge3MatRate"),file="RawBroodYrMat3.csv",ncolumns=2,sep=",")
write(t(RawMat3s),file="RawBroodYrMat3.csv",ncolumns=2,sep=",",append=TRUE)


# Ocean harvest module.  Combines information from the release file with the
# recovery file to produce ocean.harvest.dat.

# ==============================================================================

#rec <- Z$rec
#r <- R$r
#type <- R$type
#n.type <- R$n.type
#l.type <- R$l.type
#type.lab <- R$type.lab
#p <- R$p
#broods <- R$broods
#n.broods <- R$n.broods
#minage <- U$minage
#maxage <- U$maxage
#Ho.codes <- U$Ho.codes
#external.exp.factor <- U$external.exp.factor
#spatial <- U$spatial
#tagged.only <- U$tagged.only
#external.sl <- U$external.sl
#sl.default <- U$sl.default


ocean.harvest <- function(rec, r, type, n.type, l.type, type.lab, p, broods,
                          n.broods, minage, maxage, Ho.codes,
                          external.exp.factor, spatial, tagged.only,
                          external.sl, sl.default, other.data.dir, out.dir){

    Ho.rec <- rec[(rec$fishery %in% Ho.codes),]  #confine recoveries to
                                                 #ocean harvest
  
    ho <- data.frame(CWTcode = Ho.rec$tag_code, #tag code
                   agency = Ho.rec$sampling_agency, #sampling agency
                     b.yr = rep(NA, length=nrow(Ho.rec)), #brood year
                     c.yr = as.numeric(Ho.rec$run_year), #recovery year
                  recdate = ymd(Ho.rec$recovery_date), #recovery date 
                  fishery = Ho.rec$fishery, #recovery sector
                   locode = Ho.rec$recovery_location_code, #recovery location
                     site = as.character(Ho.rec$sampling_site), #sample site
                     csid = Ho.rec$catch_sample_id, #catch sample ID
                   estnum = as.numeric(Ho.rec$estimated_number), #sample exp
                   prdfct = rep(NA, length=nrow(Ho.rec)), #production factor
                     type = rep(NA, length=nrow(Ho.rec)), #type 
                 type.lab = rep(NA, length=nrow(Ho.rec)), #type label
         stringsAsFactors = FALSE)          

    cwt.codes <- unique(r$CWTcode)      #identify all CWT codes

    for(i in cwt.codes){
        b.yr.tmp <- r$b.yr[r$CWTcode==i] #link brood year with CWT code
        p.tmp <- p[r$CWTcode==i] #link production expansion with CWT code
        type.tmp <- type[r$CWTcode==i] #link type with CWT code
        type.lab.tmp <- type.lab[r$CWTcode==i] #link type with CWT code
        
        if(sum(r$CWTcode==i) > 0){
            ho$b.yr[ho$CWTcode==i] <- b.yr.tmp #assign brood year
            ho$prdfct[ho$CWTcode==i] <- p.tmp #assign production factor
            ho$type[ho$CWTcode==i] <- type.tmp #assign type 
            ho$type.lab[ho$CWTcode==i] <- type.lab.tmp #assign type label
        }
    }
    
    if(external.exp.factor == TRUE){ #insert externally estimated CWT sample 
        ho <- exp.factor(ho, other.data.dir) #expansion factors if applicable 
    }        

    # Check for inconsistencies
    NA_exp <- which(is.na(ho$estnum))
    if(length(NA_exp)>0){ #warn user if any expansion factors are NA         
  	warning(paste( "There are", length(NA_exp), 
        "RMPC data records that do not have a sample expansion factor", "\n")) 
    }

    if(tagged.only==FALSE){
  	NA_prd <- which( is.na(ho$prdfct))
  	if(length(NA_prd)>0){ #warn if any production expansion factors are NA
            warning(c(paste("There are", length(NA_prd),  
            "RMPC data records that do not have a production factor"), "\n",
	    "These are associated with the following tag codes: ",
                      paste(ho$CWTcode[NA_prd], collapse = ' '), "\n"  ) ) 
    	} 
    }

    if(spatial == TRUE){
        x <- space(ho, other.data.dir)
        ho <- x$ho
        area <- x$area
        area.lab <- x$area.lab
        n.area <- x$n.area
    }else{
        area <- "all"
        area.lab <- "all"
        n.area <- 1
    }

    months <- 1:12 #recovery month
    n.months <- length(months) #number of recovery months
    
    n.Ho.codes <- length(Ho.codes) #number of ocean harvest codes

    max.dat <- max(ho$c.yr - ho$b.yr) # max years for CWT recovery after brood year
    min.dat <- min(ho$c.yr - ho$b.yr) # min years for CWT recovery after brood year
    
    dat.length <- n.broods * (max.dat - min.dat + 1) * n.months *
                  n.Ho.codes * n.type * n.area
                                        #combination of brood years, 
                                        #recovery calendar years,
                                        #recovery months,
                                        #ocean harvest codes, types,
                                        #and area of harvest

    rec.yr <- rep(broods, each=(n.months * (max.dat - min.dat + 1) *
                                    n.Ho.codes * n.type * n.area)) +
        rep((min.dat:max.dat), each=(n.months * n.Ho.codes * n.type * n.area),
            times=n.broods)
                                        #allows recoveries confined to:
                                        #brood year + min(calendar year - brood year)
                                        #brood year + max(calendar year - brood year)

    Ho.dat <- data.frame(
        b.yr = rep(broods, each=(n.months * (max.dat - min.dat + 1) * n.Ho.codes * n.type * n.area)),
        c.yr = rec.yr,
       month = rep(months, each=(n.area * n.Ho.codes * n.type), length.out=dat.length),
        area = rep(area.lab, each=(n.Ho.codes * n.type), length.out=dat.length),
     fishery = rep(Ho.codes, each=n.type, length.out=dat.length),
        type = rep(l.type, length.out=dat.length),
           N = rep(NA, dat.length), 
       n.tag = rep(NA, dat.length),
     stringsAsFactors = FALSE)
 
    #collapse all interested fields into a new dataframe variable -
    #a character variable named 'string' 
    Ho.dat$string <- apply(Ho.dat[, c("b.yr", "c.yr", "fishery", "type", "area", "month")],
                           1, paste, collapse='.')
    ho$string <-  apply(cbind( ho[, c("b.yr", "c.yr", "fishery", "type")],
                              area, month(ho$recdate)) , 1, paste, collapse='.')
  
    Ho.dat.match <- match(ho$string, Ho.dat$string)  

    for(i in unique(Ho.dat.match)){
        if( tagged.only ){ #to reconstruct only the tagged portion of the stock
	    Ho.dat$N[i] <- round( sum( ho$estnum[Ho.dat.match==i], na.rm=T), digits=2)
	    Ho.dat$n.tag[i] <- sum(Ho.dat.match==i)   
        }else{
	    Ho.dat$N[i] <- round( sum((ho$estnum[Ho.dat.match==i] * ho$prdfct[Ho.dat.match==i]),
                                      na.rm=T), digits=2)
	    Ho.dat$n.tag[i] <- sum(Ho.dat.match==i)      
        }
    }

    #removes NA records and new string variable to reduce file size 
    Ho.dat <- Ho.dat[!is.na(Ho.dat$N), colnames(Ho.dat) != "string"]  

    Ho.dat$sl <- rep(NA, length=nrow(Ho.dat)) #create new column for minimum size limit info
    sl.match <- match(Ho.dat$fishery, sl.default$fishery) #match default size limits
                                                          #to appropriate fishery
    Ho.dat$sl <- sl.default$limit[sl.match]#assign default size limits

    if(external.sl == TRUE){                 #insert externally provided minimum
        Ho.dat <- sl(Ho.dat, other.data.dir) #size limits, if applicable
    }
  
    # save file of ocean harvest by brood year, calendar year, RMIS fishery code, and type
    sink(paste(out.dir, "ocean.harvest.dat", sep="/"))
    print(Ho.dat, row.names = F)  
    sink()
    
}

# Function that defines "strays" or returns that are classified as being 
# outside of natal river or basin.
# Example given here is fish that return to areas outside of Sacramento River
# basin for releases from Coleman National Fish Hatchery (CNFH).

stray <- function(x, other.data.dir){

    stray.field <- "locode"             # The object 'stray.field' indicates the
                                        # column name that is used to
                                        # distinguish strays.
                                        # A stray is defined by
                                        # recovery location in the RMIS V4.1
                                        # data. 

    # Read file with recovery location codes and descriptions
    # for 'natal' (non-stray) locations.
    z <- read.table(paste(other.data.dir, "natal.return.locations.txt",
                          sep="/"), header=T, sep=",")  
                                       
    stray.code <- x[,stray.field]       # field used to define strays
        
    x$stray[ !(stray.code %in% z$recovery_location_code) ] <- TRUE
    
    return(x)
}

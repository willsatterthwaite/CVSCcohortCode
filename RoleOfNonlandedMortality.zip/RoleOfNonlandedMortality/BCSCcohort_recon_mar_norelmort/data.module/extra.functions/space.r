# assign CWT recoveries to spatial area using a lookup table

space <- function(x, other.data.dir){

  z <- read.table(paste(other.data.dir, "sitearea.modified.csv", sep="/"),
                  header=T, sep=",", stringsAsFactors=FALSE)
                                        # Read lookup table that maps sampling
                                        # site to defined areas

  area <- rep(NA, length=nrow(x))
    
  for(i in 1:nrow(z)){
    ii <- x$site == z$sampsite[i]
    area[ii] <- z$area.1[i]
  }

  ##############################################################################
  # HARDCODE to remove NA area assignments
  j <- is.na(area) & x$agency != "CDFW" & x$agency != "ODFW"
  area[j] <- "NF"                       # Assign NAs to North of Falcon if
                                        # CDFW or ODFW were not sampling agency.

  x <- x[!is.na(area),]                 # Omit records with NA area 
  area <- area[!is.na(area)]            # Omit records with NA area 
  ##############################################################################

  ##############################################################################
  # HARDCODE to assign all CDFO recoveries to NF (common sampsite codes with
  # ODFW)
  k <- x$agency=="CDFO"
  area[k] <- "NF"
  ##############################################################################

  area.lab <- unique(area)
  n.area <- length(area.lab)

  list(       ho = x,
            area = area,
        area.lab = area.lab,
          n.area = n.area )
       
}

  

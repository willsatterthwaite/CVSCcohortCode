# This program produces a list of tag codes to be copied into RMIS 
# "Recoveries By Tag List" query to obtain recovery records.

# ==============================================================================
# Set working directory

#rm(list = ls(all = TRUE))

#setwd(w.dir)

# ==============================================================================
# Sub-directories

query.dir <- "query.module"                   # query module directory

# specify paths
releases.fn   <- paste(query.dir,  "releases.csv", sep="/")
tag.codes.fn  <- paste(query.dir, "tag.codes.txt", sep="/") 

# ==============================================================================
# Run program

# Reads raw CWT release data (releases.csv)
#-------------------------------------------------------------------------------
# releases
  
rel <- read.table(releases.fn,
                  sep=",",
                  header=T,
                  colClasses="character")  # read all columns in as character
                 
# ------------------------------------------------------------------------------
# print the list of unique tag codes to a .txt file

tag.codes <- data.frame(x = unique(rel$tag_code_or_release_id))

write.table(tag.codes, file=tag.codes.fn, quote=FALSE, row.names=FALSE,
            col.names=FALSE)

# ------------------------------------------------------------------------------
# Print the list of unique tag codes split up into groups of 1000.
# Each group of 1000 prints to a .txt file

if(nrow(tag.codes) > 1000){
    
    n.files <- ceiling(nrow(tag.codes)/1000)
    
    counter <- 1
    
    for(i in 1:n.files){
        fn <- paste(query.dir, 
                    paste("tag.codes", i, ".txt", sep=""), sep="/")
        
        end.position <- min((counter + 1000 - 1), nrow(tag.codes))
        
        write.table(tag.codes[counter:end.position,], file=fn, 
                    quote=FALSE, row.names=FALSE, col.names=FALSE)
        
        counter <- counter + 1000
    }
}	

# ==============================================================================







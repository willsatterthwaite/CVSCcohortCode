#  Read data module.  Reads raw CWT release and recovery data.

# ==============================================================================

read.data <- function(releases, recoveries, nat.origin,
                      out.dir, natural.origin){

#-------------------------------------------------------------------------------
# releases
  
    rel <- read.table(releases,
                      sep=",",
                      header=T,
                      stringsAsFactors = FALSE)
    
#-------------------------------------------------------------------------------
# recoveries
    
    rec <- read.table(recoveries,
                      sep=",",
                      header=T,
                      stringsAsFactors = FALSE) 
    
# issue a warning if tag codes in the recovery file are not present in 
# the release file

    if(sum(!(rec$tag_code %in% rel$tag_code_or_release_id)) > 0 ){
        warning(paste("There is at least one tag code in the recovery data",
                      "file that is not present in the release data file. ", 
                      "Rerun recovery query.",
                      sep=" "))
    }

#-------------------------------------------------------------------------------
# natural-origin returns

    if( natural.origin ){
        
        nat <- read.table(nat.origin,
                          sep="",
                          header=T)
        
        sink(paste(out.dir, "nat.origin.returns.dat", sep="/"))
        print(nat, row.names=F)
        sink()
    }     
#-------------------------------------------------------------------------------
        
    list(rel = rel,
         rec = rec)
        
    }
    



#  Read in user-defned inputs.
# ==============================================================================

user.inputs <- function(input.dir){

#-------------------------------------------------------------------------------
# read in user-defined inputs
    
    minage <- min(scan(paste(input.dir, "ages.par", sep="/"), quiet=TRUE))
                                        # Minimum years after brood year
    
    maxage <- max(scan(paste(input.dir, "ages.par", sep="/"), quiet=TRUE))
                                        # Maximum years after brood year
    
    E.codes <- scan(paste(input.dir,
                          "escapement.codes.par", sep="/"),
                    quiet=TRUE)
                                        # RMPC escapement codes may include
                                        # "fisheries" 50-59.
    
    Hr.codes <- scan(paste(input.dir,
                           "river.fishery.codes.par", sep="/"),
                     quiet=TRUE)
                                        # RMPC codes could include "fisheries'
                                        # 21-49.
    
    Ho.codes <- scan(paste(input.dir,
                           "ocean.fishery.codes.par", sep="/"),
                     quiet=TRUE)
                                        # RMPC troll fishery codes include
                                        # "fisheries" 10-19. Sport fishery
                                        # codes include fisheries 40-49.
    
    external.exp.factor <- scan(paste(input.dir,
                                      "external.exp.factor.par", sep="/"),
                                what="logical", quiet=TRUE)
                                        # TRUE if externally-estimated
                                        # CWT sample expansion factors are to
                                        # be used.  FALSE if expansion factors
                                        # only from RMPC recovery file to be
                                        # used.

    multiple.types <- scan(paste(input.dir,
                                 "multiple.types.par", sep="/"),
                           what="logical", quiet=TRUE)
                                        # TRUE if reconstruction of multiple
                                        # release types will occur, else FALSE.
                                        # A 'type' indicates the base level for
                                        # cohort reconstruction. If no types,
                                        # the reconstructions are performed
                                        # on all varieties of releases.
    
    strays <- scan(paste(input.dir, "strays.par", sep="/"),
                   what="logical", quiet=TRUE)
                                        # TRUE if there is a desire to identify
                                        # and estimate the number and rate of
                                        # "strays": freshwater recoveries
                                        # outside of a defined natal area.
                                        # If FALSE, no recoveries are
                                        #classified as strays.
        
    natural.origin <- scan(paste(input.dir,
                                       "natural.origin.par", sep="/"),
                                 what="logical", quiet=TRUE)
                                        # TRUE if a natural origin component 
                                        # will be reconstructed, else FALSE.

    spatial <- scan(paste(input.dir,
                          "spatial.par", sep="/"),
                    what="logical", quiet=TRUE)
                                        # TRUE if ocean fishery recoveries are
                                        # to be spatially stratified.  FALSE
                                        # proceeds with no spatial
                                        # stratification.
    
    tagged.only <- scan(paste(input.dir,
                          "tagged.only.par", sep="/"),
                    what="logical", quiet=TRUE)
                                        # TRUE if only tagged portion of ocean 
					# fishery recoveries are to be
                                        # reconstructed.
					# FALSE if both tagged and untagged
                                        # portions are reconstructed.

    external.sl <-  scan(paste(input.dir,
                               "external.size.limits.par", sep="/"),
                         what="logical", quiet=TRUE)
                                        # TRUE if minimum size limit data
                                        # are to be provided.  FALSE if
                                        # default minimum size limits will
                                        # be assumed.
    
    sl.default <- read.table(paste(input.dir,"default.size.limits.par",sep="/"),
                             header=TRUE, sep="")
                                        # Establishes default mininum size
                                        # limits, stratified by fishery, in
                                        # cases where no external size limit
                                        # regulations are provided.

#-------------------------------------------------------------------------------  
    list(                minage = minage,
                         maxage = maxage,
                        E.codes = E.codes,
                       Hr.codes = Hr.codes,
                       Ho.codes = Ho.codes,
            external.exp.factor = external.exp.factor,
                 multiple.types = multiple.types,
                         strays = strays,
                 natural.origin = natural.origin,
                        spatial = spatial,
	            tagged.only = tagged.only,
                    external.sl = external.sl,
                     sl.default = sl.default
         )
}




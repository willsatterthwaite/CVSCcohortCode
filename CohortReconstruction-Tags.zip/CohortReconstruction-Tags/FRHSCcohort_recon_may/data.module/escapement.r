# Escapement module.  Combines information from the release file with the
# recovery file to produce escapement.dat.

# ==============================================================================

#rec <- Z$rec
#r <- R$r 
#type <- R$type
#n.type <- R$n.type
#l.type <- R$l.type
#type.lab <- R$type.lab
#p <- R$p
#broods <- R$broods
#n.broods <- R$n.broods
#minage <- U$minage
#maxage <- U$maxage
#E.codes <- U$E.codes
#external.exp.factor <- U$external.exp.factor
#strays <- U$strays
#tagged.only <- U$tagged.only 


escapement <- function(rec, r, type, n.type, l.type, type.lab, p, broods,
                       n.broods, minage, maxage, E.codes, external.exp.factor,
                       strays, tagged.only, other.data.dir, out.dir){


    e.rec <- rec[(rec$fishery %in% E.codes),] #confine recoveries to
                                              #escapement series
  
    e <- data.frame(CWTcode = e.rec$tag_code, #tag code
                       b.yr = rep(NA, length=nrow(e.rec)),#brood year
                       c.yr = as.numeric(e.rec$run_year),#recovery year
                    fishery = e.rec$fishery,#recovery sector
                     locode = e.rec$recovery_location_code,#recovery location
		      stray = rep(FALSE, length=nrow(e.rec)),#stray classification
                       csid = e.rec$catch_sample_id,#catch sample ID
                     estnum = as.numeric(e.rec$estimated_number),#sample exp factor
                     prdfct = rep(NA, length=nrow(e.rec)),#production factor
                       type = rep(NA, length=nrow(e.rec)),#type 
                   type.lab = rep(NA, length=nrow(e.rec)),#type label
           stringsAsFactors = FALSE)          

    cwt.codes <- unique(r$CWTcode)         #identify all CWT codes

    for(i in cwt.codes){
        b.yr.tmp <- r$b.yr[r$CWTcode==i] #link brood year with CWT code
        p.tmp <- p[r$CWTcode==i]    #link production expansion with CWT code
        type.tmp <- type[r$CWTcode==i] #link type with CWT code
        type.lab.tmp <- type.lab[r$CWTcode==i] #link type label with CWT code
        
        if(sum(r$CWTcode==i) > 0){
            e$b.yr[e$CWTcode==i] <- b.yr.tmp # assign brood year
            e$prdfct[e$CWTcode==i] <- p.tmp # assign producton factor 
            e$type[e$CWTcode==i] <- type.tmp # assign type to recovery
            e$type.lab[e$CWTcode==i] <- type.lab.tmp # assign type 
        }
    }
    
    if(external.exp.factor == TRUE){      #call function to assign external
        e <- exp.factor(e, other.data.dir)  #sample expansion factors, if
    }                                     #applicable
    
    # Check for inconsistencies
    NA_exp <- which( is.na(e$estnum))
    if(length(NA_exp)>0){ #warn user if any expansion factors are NA         
  	warning(paste( "There are", length(NA_exp), 
        "RMPC data records that do not have a sample expansion factor", "\n")) 
    }
    
    if(tagged.only==FALSE){
  	NA_prd <- which( is.na(e$prdfct))
  	if(length(NA_prd)>0){#warn user if any production expansion
                             #factors are NA
            warning(c(  paste( "There are", length(NA_prd),
            "RMPC data records that do not have a production factor"), "\n",
            "These are associated with the following tag codes: ",
                      paste(e$CWTcode[NA_prd], collapse = ' '), "\n"  ) ) 
        }
    }

    if(strays == TRUE){               #call function to identify
        e <- stray(e, other.data.dir) #'stray' CWT recoveries
    }
    
    n.esc.codes <- length(E.codes)    #number of escapement codes

    max.dat <- max(e$c.yr - e$b.yr) # max years for CWT recovery after brood year
    min.dat <- min(e$c.yr - e$b.yr) # min years for CWT recovery after brood year
        
    dat.length <- n.broods * (max.dat - min.dat + 1) * n.esc.codes * n.type
                                        #Combination of brood years, 
                                        #recovery calendar years,
                                        #escapement codes, and types

    rec.yr <- rep(broods, each=((max.dat - min.dat + 1) * n.esc.codes * n.type)) +
        rep((min.dat:max.dat), each=(n.esc.codes * n.type), times = n.broods)
                                        #allows recoveries confined to:
                                        #brood year + min(calendar year - brood year)
                                        #brood year + max(calendar year - brood year)

    #set up data frame for escapement data
    esc.dat <- data.frame(b.yr = rep(broods, each=((max.dat - min.dat + 1) * n.esc.codes*n.type)),
                          c.yr = rec.yr,
                          code = rep(E.codes, each=n.type, length.out=dat.length),
                          type = rep(l.type, length.out=dat.length),
                             N = rep(NA, dat.length),
                         n.tag = rep(NA, dat.length),
	               N.stray = rep(NA, dat.length),
         	   n.tag.stray = rep(NA, dat.length),
              stringsAsFactors = FALSE)

    for(i in 1:nrow(esc.dat)){
        ii <- (e$b.yr == esc.dat$b.yr[i] &
                   e$c.yr == esc.dat$c.yr[i] &
                       e$fishery == esc.dat$code[i] &
                           e$type == esc.dat$type[i])
        
        if(sum(ii) > 0){
            ii.stray <- ii &  e$stray
            ii.natal <- ii & !e$stray
            
            if( tagged.only){

                esc.dat$N[i] <- round( sum( e$estnum[ii.natal], na.rm=T), digits=2)
                esc.dat$n.tag[i] <- sum(ii.natal)
                esc.dat$N.stray[i] <- round( sum( e$estnum[ii.stray], na.rm=T), digits=2)
                esc.dat$n.tag.stray[i] <- sum(ii.stray)
                                        #sums sample
                                        #expansion factor for all recoveries,
                                        #but omits records when either expansion
                                        #factor is NA
            }else{
                
                esc.dat$N[i] <- round(sum((e$estnum[ii.natal] * e$prdfct[ii.natal]), na.rm=T),
                                      digits=2)
                esc.dat$n.tag[i] <- sum(ii.natal)
                esc.dat$N.stray[i] <- round(sum((e$estnum[ii.stray] * e$prdfct[ii.stray]), na.rm=T),
                                            digits=2) 
                esc.dat$n.tag.stray[i] <- sum(ii.stray)
                                        #sums production expansion factor * sample
                                        #expansion factor for all recoveries,
                                        #but omits records when either expansion
                                        #factor is NA
            }
        }
    }
   
    esc.dat <- esc.dat[!is.na(esc.dat$N),]#removes NA records to reduce file size

    #save file of escapement by brood year, calendar year, RMIS code, and type
    sink(paste(out.dir, "escapement.dat", sep="/"))
    print(esc.dat, row.names = F)
    sink()
    
}

# Function that defines "types" or components of hatchery releases that will
# be reconstructed separately.  Example given here is onsite versus offsite
# releases from Coleman National Fish Hatchery (CNFH).

types <- function(rel){

    type.field <- "release_location_code" # 'type.field' indicates the
                                          # column name that is used to
                                          # distinguish type.
                                          # For this example, type is defined by
                                          # release location in the RMIS V4.1
                                          # data. 

    type.code <- rel[,type.field]         # field used to define types

    n.type <- 2                           # Number of distinct types

    type.1 <- 1                           # Onsite releases
    type.2 <- 2                           # Offsite releases

    l.type <- c(type.1, type.2)           # Concatonate types
    
    type.1.lab <- "CNFH"                  # Type 1 label
    type.2.lab <- "offsite"               # Type 2 label

    type.labels <- c(type.1.lab, type.2.lab) # Concatonate type labels

    type <- type.lab <- rep(NA, nrow(rel))  # Define type vector
  
    # identify types based on type.field
    type[substr(type.code,10,20) == type.1.lab] <- type.1 #onsite releases
    type[substr(type.code,10,20) != type.1.lab] <- type.2 #offsite releases

    type.lab[substr(type.code,10,20) == type.1.lab] <- type.1.lab #onsite
    type.lab[substr(type.code,10,20) != type.1.lab] <- type.2.lab #offsite

    
    list(     n.type = n.type,
              l.type = l.type,
         type.labels = type.labels,
                type = type,
            type.lab = type.lab)
}


# Hatchery-origin cohort reconstruction.
# ==============================================================================

cohort.analysis.hat <- function(R.D) {

     # Data and parameters.
     # --------------------
        Z <- R.D$Z
        X <- R.D$X
      d.o <- R.D$d.o
      d.r <- R.D$d.r
    R.hat <- R.D$R.hat
        v <- R.D$v
      age <- R.D$age
      mat <- R.D$mat
      b.y <- R.D$b.y
   b.y.co <- R.D$b.y.co
   b.y.in <- sort(R.D$b.y.in)
   months <- R.D$months
    types <- R.D$types
    

     # Ocean fishery contacts, release mortality, dropoff mortality, impacts.   
     # ----------------------------------------------------------------------
        
     Z$C <- Z$H.o / Z$plegal                   #ocean fishery contacts

     if(any(is.na(Z$plegal)))
         warning(paste("Ocean contacts are assumed to be equal to ocean harvest where plegal=NA", "\n"))

     Z$C[is.na(Z$plegal)] <- Z$H.o[is.na(Z$plegal)]

     Z$S <- (Z$C - Z$H.o) * Z$mort.rate.s      #release (shaker) mortality
     Z$D <- Z$C * d.o                          #dropoff mortality
     Z$I <- Z$H.o + Z$S + Z$D                  #impacts

     #sum impacts over area, fishery  #NOTE: NA's will carry through,
     #Z includes only observed data
     I.m.sum <- aggregate(I ~ b.yr + c.yr + month + age + type, data=Z,
                          FUN=sum, na.action=na.pass)
     #sum harvest over area, fishery
     H.m.sum <- aggregate(H.o ~ b.yr + c.yr + month + age + type, data=Z,
                          FUN=sum, na.action=na.pass)
     #sum contacts over area, fishery
     C.m.sum <- aggregate(C ~ b.yr + c.yr + month + age + type, data=Z,
                          FUN=sum, na.action=na.pass)

     #add harvest and contacts column to I.m.sum for output
     I.m.sum$H.o <- H.m.sum$H.o
     I.m.sum$C   <- C.m.sum$C

     # River fishery dropoff mortality, impacts, river mouth return.   
     # -------------------------------------------------------------

     R.hat$D.r <- R.hat$H.r * d.r       #river fishery dropoff mortality
     R.hat$I.r <- R.hat$H.r + R.hat$D.r #river impacts = harvest + dropoffs

     R.hat$R <- rowSums(cbind(R.hat$I.r, R.hat$E),na.rm=TRUE)#river mouth return
     R.hat$n.tag.tot <- rowSums(cbind(R.hat$n.tag.Hr, R.hat$n.tag.E),na.rm=TRUE)
        
     # Expand impacts and escapement dataframes to include zeros for brood
     # years, ages, months, and types, with no CWT recoveries.
     # ------------------------------------------------------------------------
 
     #dataframe with all possible brood years, types, ages, and months
     df <- expand.grid(b.yr = b.y, type = types, age = age, month = months)

     #compute calendar year from brood year and age
     df$c.yr[df$month <= mat] <-
         df$b.yr[df$month <= mat] + df$age[df$month <= mat]     
     df$c.yr[df$month  > mat] <-
         df$b.yr[df$month  > mat] + df$age[df$month  > mat] - 1 

     #merge: right outer join
     N <- merge(x=I.m.sum, y=df, by=c("b.yr", "c.yr", "month", "age", "type"),
                all.y=TRUE) 
          # note: if all.y= TRUE, then extra rows will be added to the output, 
	  # one for each row in y that has no matching row in x. 

     N[is.na(N)] <- 0 

     N$n.tag.Hr <- N$n.tag.E <- N$E <- N$H.r <- N$D.r <- N$I.r <- N$M <- N$W <-
         N$n.tag.W <- N$R <- N$N.h <- N$V <-  NA
        
     # Initialize cohort reconstruction: complete broods.
     # --------------------------------------------------

     for (i in 1:nrow(R.hat)){  # assign river return to the maturation month
         ii <- N$b.yr==R.hat$b.yr[i] & N$age==R.hat$age[i] &
               N$type==R.hat$type[i] & N$month==mat 
      N[ii, c('R', 'H.r', 'D.r', 'I.r', 'W', 'n.tag.W', 'E', 'n.tag.Hr', 'n.tag.E')] <- 
	 R.hat[i, c('R', 'H.r', 'D.r', 'I.r', 'W', 'n.tag.tot.W', 'E', 'n.tag.Hr', 'n.tag.E')]
     }

     #calculate total ocean escapement
     N$M <- N$W + N$R

     # add max age + 1 rows for complete broods
     N.max <- data.frame(b.yr = b.y.co, c.yr = NA, month = months[1], 
                         age = max(age)+1, type = rep(types, each=length(b.y.co)),
                         I = 0, H.o = 0, C = 0, V = 0, N.h=0, 
                         R = NA, n.tag.W = NA, W = NA, M = NA, I.r = NA, D.r = NA,
                         H.r = NA, E = NA, n.tag.E = NA, n.tag.Hr = NA) 

     N <- rbind(N, N.max)

     N <- N[order(N$b.yr, N$age, match(N$month, months)),]

        
     # Reconstruction of complete broods.
     # ==================================

     for (t in types){
         for (b in b.y.co){
             for (a in rev(age)){
                 for (m in length(months):1 ){
                     # natural mortality rate
                     v.i <- ((v$mort.rate.v[v$age==a & v$month==months[m]]) /
                            (1-(v$mort.rate.v[v$age==a & v$month==months[m]]))) 

                     i <- N$type==t & N$b.yr==b & N$age==a & N$month==months[m]
                     j <- N$type==t & N$b.yr==b & N$age==a + 1 & N$month==months[1]
                     k <- N$type==t & N$b.yr==b & N$age==a & N$month==months[m+1]

                     if(months[m]==mat){
                         N$V[i]   <- (N$N.h[j] + N$M[i]) * v.i
                         N$N.h[i] <- N$I[i] + N$V[i] + N$M[i] + N$N.h[j]
                     }
                     if(months[m]!=mat){
                         N$V[i]   <- N$N.h[k] * v.i
                         N$N.h[i] <- N$I[i] + N$V[i] + N$N.h[k]
                     }
                 }
             }
         }
     }
                    
     N <- N[N$age <= max(age),] #remove rows for fish greater than the max age
        

    # Estimate maturation rates.
    # --------------------------

    E <- N[N$month==mat & N$b.yr %in% b.y.co,]  
    E$e <- E$M / (E$N.h - E$I - E$V)
      
    if(any(is.nan(E$e)))  # Change NAN maturation rates to 1 and give user warning
        warning(c("For brood year(s) ", paste(unique(E$b.yr[ is.nan(E$e) ]),
                                              collapse = ' '),
	"\n", "Ages(s) ", paste(sort(unique(E$age[ is.nan(E$e) ])), collapse = ' '),
        "\n", "Type(s) ", paste(sort(unique(E$type[ is.nan(E$e) ])), collapse = ' '),
	"\n", "maturation rate set to 1", "\n" ))

    E$e[ is.nan(E$e) ] <- 1

    # Estimate stray rates.
    # --------------------------
            
    E$w <- E$W / E$M

        
    # Reconstruction of incomplete broods.
    # ====================================
    # Allows for a maximum of three incomplete broods    

    #calculate average maturation rates for complete broods
    Avg.e <- aggregate(e ~ age + type, data=E[E$b.yr %in% b.y.co,], FUN=mean)

    if (length(b.y.in) > 0 ){
        for (t in types){
            for (b in 1:length(b.y.in) ){
                for (a in rev(age)[-(1:b)] ){
                    for (m in length(months):1){
                        
                        i <- N$type==t & N$b.yr==b.y.in[b] & N$age==a & N$month==months[m]
                        j <- N$type==t & N$b.yr==b.y.in[b] & N$age==a + 1 & N$month==months[1]
                        k <- N$type==t & N$b.yr==b.y.in[b] & N$age==a & N$month==months[m+1]

                        #natural mortality rate
                        N$v[i] <- v$mort.rate.v[v$age==a & v$month==months[m]] 
                      
                        #compute abundance, impacts, and natural mortality at
                        #the end of age [max(age)-1] for the first incomplete brood.
                        #use average maturation rates of age [max(age)-1]
                        if(a == (max(age)-1) & b == 1 & months[m] == mat){
                            e.m.1 <- Avg.e$e[Avg.e$age == (max(age) - 1) & Avg.e$type==t]
                            N$N.h[i] <- ((N$M[i] / e.m.1) / (1 - N$v[i])) + N$I[i]
                            N$V[i]   <- ( N$N.h[i] - N$I[i]) * N$v[i]
                        }
                      
                        #compute abundance, impacts, and natural mortality at 
                        #the end of age [max(age)-2] for the second incomplete brood.
                        #use average maturation rates of age [max(age)-2]
                        if(a == (max(age)-2) & b == 2 & months[m] == mat){
                            e.m.2 <- Avg.e$e[Avg.e$age == (max(age) - 2) & Avg.e$type==t]
                            N$N.h[i] <- ((N$M[i] / e.m.2) / (1 - N$v[i])) + N$I[i]
                            N$V[i]   <- ( N$N.h[i] - N$I[i]) * N$v[i]
                        }
                      
                        #compute abundance, impacts, and natural mortality at 
                        #the end of age [max(age)-3] for the third incomplete brood
                        #use average maturation rates of age [max(age)-3]
                        if(a == (max(age)-3) & b == 3 & months[m] == mat){
                            e.m.3 <- Avg.e$e[Avg.e$age == (max(age) - 3) & Avg.e$type==t]
                            N$N.h[i] <- ((N$M[i] / e.m.3) / (1 - N$v[i])) + N$I[i]
                            N$V[i]   <- ( N$N.h[i] - N$I[i]) * N$v[i]
                        }
                                            
                        #compute abundance, impacts, and natural mortality for the month
                        #of maturation for age < max age
                        if(months[m] == mat & a < max(rev(age)[-(1:b)])){
                            N$N.h[i] <- ((N$N.h[j] + N$M[i]) / (1 - N$v[i])) +  N$I[i]	
                            N$V[i]   <- ( N$N.h[i] - N$I[i]) * N$v[i]
                        }
                      
                        #compute abundance, impacts, and natural mortality for all other months
                        if(months[m] != mat){
                            N$N.h[i] <- ( N$N.h[k] / (1 - N$v[i])) +  N$I[i]
                            N$V[i]   <- ( N$N.h[i] - N$I[i]) * (N$v[i])
                        }
                    }
                }
            }
        }
    }
        
    # Remove unobserved data (i.e., ages from incomplete broods that have yet to return).
    # -----------------------------------------------------------------------------------
    N <- N[!is.na( N$N.h),]

    # Warn user if N = NA but I > 0.         
    # ------------------------------
    if(any(is.na(N$N.h) & N$I > 0))
        warning( "Abundance is NA but impacts are estimated to be greater than zero on at 
                  least one occasion.  Check specification of incomplete/complete cohorts.")
   
    # Estimate maturation rates.
    # --------------------------
    E <- N[N$month==mat,]  #replace E with updated info on incomplete cohorts

    E$e <- E$M / (E$N.h - E$I - E$V)

    E$e[is.nan(E$e)] <- 1  

    E$w <- E$W / E$M

    # Estimate river harvest and impact rates.
    # ----------------------------------------
    E$h.r <- E$H.r / E$R
    E$i.r <- E$I.r / E$R

    # Calculate stratum-specific ocean contact, harvest, release, dropoff, and impact rates.
    # --------------------------------------------------------------------------------------
    Z <- merge(x=Z, y=N[, c("c.yr", "b.yr", "age", "month", "type", "N.h")], all.x=TRUE)
                                        # Keep all rows in Z
    Z <- Z[!is.na(Z$N.h),]
		# Remove unobserved data 
		# (i.e., ages from incomplete broods that have yet to return).

    Z$h <- Z$H.o / Z$N.h
    Z$c <- Z$C   / Z$N.h
    Z$s <- Z$S   / Z$N.h
    Z$d <- Z$D   / Z$N.h
    Z$i <- Z$I   / Z$N.h 
        
        
   # Estimate annual contact rates, harvest rates, impact rates.
   # -----------------------------------------------------------

   A <- aggregate(cbind(C, H.o, I) ~ b.yr + type + age, data=N, FUN=sum)

    for(i in 1:nrow(A)){
        ii <- N$b.yr==A$b.yr[i] & N$age==A$age[i] & N$type==A$type[i] & N$month==months[1]
        A$N.h[i] <- N$N.h[ii]
    }
    colnames(A)[colnames(A) == c("N.h")] <- "N" # change column names

   # contact, harvest, and impact rates
   A$c <- A$C   / A$N
   A$h <- A$H.o / A$N
   A$i <- A$I   / A$N

   # Change row and column order for output.         
   #----------------------------------------

   N <- N[ order(N$type, N$b.yr, N$age, match( N$month, months)), 
          c("b.yr", "c.yr", "age", "month", "type", "N.h", "I", "V",
            "M", "W", "R", "H.r", "D.r", "I.r", "E", "n.tag.Hr", "n.tag.E", "n.tag.W")]

  # Output.
  # -------

  # save annual rates 
  sink(paste(out.dir, "A.dat", sep="/"))
  print(A, row.names = F)  
  sink()

  # save  monthly abundances 
  sink(paste(out.dir, "N.dat", sep="/"))
  print(N, row.names = F)  
  sink()

  # save stratum specific, monthly rates 
  sink(paste(out.dir, "Z.dat", sep="/"))
  print(Z, row.names = F)  
  sink()

  # save  maturation rates 
  sink(paste(out.dir, "E.dat", sep="/"))
  print(E, row.names = F)  
  sink()

  # save release data      
  sink(paste(out.dir, "X.dat", sep="/"))
  print(X, row.names=F)
  sink()

        
  list( A = A,
        N = N,
        Z = Z,
        E = E )

  }

# ============================================================================
        

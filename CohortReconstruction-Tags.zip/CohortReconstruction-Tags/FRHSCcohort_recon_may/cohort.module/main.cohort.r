# ==============================================================================
# This program controls the running of the modules implementing the cohort
# reconstruction algorithm.
# The individual modules include:    
# read.data.r - reads user defined inputs and core data and reconfigures
#               these data for the cohort reconstruction
# cohort.analysis.hat.r - reconstructs hatchery-origin cohorts
# cohort.analysis.nat.r - reconstructs natural-origin cohorts
#
# =============================================================================
 
#rm(list = ls(all = TRUE))

# Set working directory.
# ------------------------------------

#setwd(w.dir)
 
options(warning.length=8170)  # To print verbose warnings

# capture all the output to a file.
zz <- file("warnings.cohort.module.txt", open = "wt")
sink(zz, type = "message")

# Sub-directories
# ------------------------------------

cohort.mod.dir <- "cohort.module"

data.input.dir <- "cohort.module/cohort.input.data" # subdirectory for inputs 
						    # from the data module
user.input.dir <- "user.inputs"                # subdirectory for user-defined
                                               # inputs
out.dir <- "output.module/cohort.output"       # subdirectory to store output

x.fun.dir <- "cohort.module/extra.functions" # subdirectory for functions
                                             # defining additional structure for
                                             # cohort reconstruction

# Read component programs into memory.
# ------------------------------------

source(paste(cohort.mod.dir, "read.data.r",           sep="/"))
source(paste(cohort.mod.dir, "cohort.analysis.hat.r", sep="/"))
source(paste(cohort.mod.dir, "cohort.analysis.nat.r", sep="/"))
source(paste(x.fun.dir     , "get.Age.r"            , sep="/"))


# Increase output file line length.
# ---------------------------------

default.output.file.line.nchar <- getOption("width")
options(width=300)  # reset to 300
options(max.print=10E05) # allows for 10000 rows in output files
options(scipen=10) # suppresses scientific notation


# Specify Input filenames.
# -------------------------------------------

# Input data:
data <- list(r   = "releases.dat",      
             ho  = "ocean.harvest.dat", 
             e   = "escapement.dat",    
             hr  = "river.harvest.dat", 
             nat = "nat.origin.returns.dat" 
             )

# Input parameters:
par <- list( b.y.co = "complete.broods.par",   
             b.y.in = "incomplete.broods.par", 
                age = "ages.par",             
                mat = "mature.month.par",     
                  l = "length.at.age.par",    
                d.o = "drop.off.ocean.par",
                d.r = "drop.off.river.par",
              ext.s = "external.release.mort.rate.par",        
                  s = "release.mort.rate.par", 
              def.s = "default.release.mort.rate.par", 
                  v = "natural.mort.rate.par",   
            E.codes = "escapement.codes.par",
           Hr.codes = "river.fishery.codes.par",
           Ho.codes = "ocean.fishery.codes.par",
                nat = "natural.origin.par"
              )

data <- lapply(data, function(i) paste(data.input.dir, i, sep="/" ))
 par <- lapply( par, function(i) paste(user.input.dir, i, sep="/" ))

# Output:
fo <- list(out.1 = "bcamxf.out",
           out.2 = "bcam.out",
           out.3 = "ba.out",  
           out.4 = "b.out",   
           out.5 = "bcamxf.nat.out", 
           out.6 = "bcam.nat.out",   
           out.7 = "ba.nat.out",     
           out.8 = "b.nat.out"       
           )

fo <- lapply(fo, function(i) paste(out.dir, i, sep="/" ))

# Read data and parameters into storage arrays.
# ---------------------------------------------
R.D <- read.data(par, data)

# Cohort analysis.
# ----------------
C.A.hat <- cohort.analysis.hat(R.D) # hatchery-origin

if(R.D$nat){
    C.A.nat <- cohort.analysis.nat(R.D, C.A.hat) # natural-origin
}

# Reset print options.
# --------------------
options(width=default.output.file.line.nchar)




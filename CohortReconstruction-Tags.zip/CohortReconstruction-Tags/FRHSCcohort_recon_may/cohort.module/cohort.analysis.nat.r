# Natural-origin cohort reconstruction.
# ==============================================================================

cohort.analysis.nat <- function(R.D, C.A.hat) {

   # Data and parameters.
   # --------------------

      d.o <- R.D$d.o
        v <- R.D$v
      age <- R.D$age
      mat <- R.D$mat
      b.y <- R.D$b.y
   b.y.co <- R.D$b.y.co
   b.y.in <- sort(R.D$b.y.in)
   months <- R.D$months
    types <- R.D$types
    R.nat <- R.D$R.nat
        Z <- C.A.hat$Z
        E <- C.A.hat$E

   # Calculate stratum specific contact, harvest, release, dropoff, and
   # impact rates. Sum over types.
   # ------------------------------------------------------------------

   Z.nat <- aggregate(cbind(C, I, N.h) ~ c.yr + month + age + b.yr + fishery + area,
                      data= Z, FUN=sum, na.action=na.pass)

   Z.ps.type1 <- Z[Z$type==1, c("c.yr", "month", "age", "b.yr", 
                        "fishery", "area", "plegal", "mort.rate.s")]
     

   Z.nat <- merge(Z.nat, Z.ps.type1, all.x=TRUE)
				#this is to obtain proportion legal and 
				#release mortality from type 1 hatchery
				#releases. Assumes these values are not
				#type specific. 

   Z.nat$c.est <- Z.nat$C / Z.nat$N.h
   Z.nat$i.est <- Z.nat$I / Z.nat$N.h

   #remove hatchery abundance from natural origin data
   Z.nat <- Z.nat[,colnames(Z.nat) != "N.h"]
				

   # Calculate month specific quantities: 
   # impact rates, natural mortality rates, river returns, monthly abundances.
   # -------------------------------------------------------------------------
      
   N.nat <- aggregate(cbind(c.est, i.est) ~ c.yr + b.yr + age + month, data=Z.nat,
                         FUN=sum, na.action=na.pass)

   R.nat$month <- mat #assign maturation month to natural-origin river returns
   colnames(R.nat)[colnames(R.nat) == "N"] <- "R" #change column names
   R.nat$c.yr <- R.nat$b.yr + R.nat$age           #compute calendar year of returns

   N.nat <- merge(N.nat, R.nat, all=TRUE) #merge river run size with ocean information

   df <- expand.grid(b.yr = b.y, age = age, month = months)

   #compute c.yr from b.yr and age
   df$c.yr[df$month <= mat] <- df$b.yr[df$month <= mat] + df$age[df$month <= mat]     
   df$c.yr[df$month  > mat] <- df$b.yr[df$month  > mat] + df$age[df$month  > mat] - 1 

   N.nat <- merge( N.nat, df, all.y=TRUE) #N.nat includes all months and broods 
                                          #including ages from incomplete broods
                                          #that have yet to return.
                                          #NAs occur for incomplete broods/ages
                                          #and when i.est is not specified.

   #set contact and impact rates for max age equal to the contact rates for max age - 1.
   #contact and impact rates for max age unreliable owing to sparse recoveries.
   for(i in 1:nrow(N.nat)){
       if(N.nat$age[i]==max(N.nat$age)){
           N.nat$c.est[i] <- N.nat$c.est[N.nat$b.yr==N.nat$b.yr[i] &
                                             N.nat$month==N.nat$month[i]&
                                                 N.nat$age==(N.nat$age[i]-1)]
           N.nat$i.est[i] <- N.nat$i.est[N.nat$b.yr==N.nat$b.yr[i] &
                                             N.nat$month==N.nat$month[i]&
                                                 N.nat$age==(N.nat$age[i]-1)]
       }
   }
      
   N.nat$i.est[is.na(N.nat$i.est)] <- 0 #set NA impact rates to zero

   N.nat$V <- N.nat$v <- N.nat$N.n <- N.nat$I <- N.nat$M <- N.nat$W <- NA
   N.nat <- N.nat[ , c("b.yr", "c.yr", "age", "month", "i.est", "I", "v",
                       "V", "M", "W", "R", "N.n")]
   

  #if i.est=1 force the impact rate to be equal it to the next highest
  #value observed in the data.  Impact rate of 1 gives abundance of Inf
  N.nat$i.est[N.nat$i.est>=1] <- max(N.nat$i.est[ N.nat$i.est < 1])

  # Calculate the average stray rate for hatchery fish.
  # Average over types and cohorts.
  # ---------------------------------------------------
  Avg.w <- aggregate(w ~ age, data=E, FUN=mean)  

  Avg.w$w[Avg.w$w>=1] <- max(Avg.w$w[ Avg.w$w < 1])  #for cases where the average
                                                     #stray rate == 1, replace with 
                                                     #with the next highest mean value
  i <- match(N.nat$age, Avg.w$age)
  N.nat$W <- N.nat$R * Avg.w$w[i] / (1 - Avg.w$w[i])
  N.nat$M <- N.nat$R + N.nat$W

  N.nat$W[is.na(N.nat$W)] <- 0          #if strays are NA, set to 0
  N.nat$M[is.na(N.nat$M)] <- 0          #if mature fish are NA, set to 0
      
  # Reconstruction of complete broods.
  # ==================================
  # add max age + 1 rows
  N.nat.max <- data.frame(c.yr = NA, b.yr = b.y.co, month = months[1], age = max(age)+1,
                          i.est = 0, I = 0,  v = 0, V=0, M = NA, W = NA, R = NA,
                          N.n = 0)

  N.nat <- rbind(N.nat, N.nat.max)

  for (b in b.y.co){
      for (a in rev(age)){
          for (m in length(months):1){
              
              i <- N.nat$b.yr==b & N.nat$age==a     & N.nat$month==months[m]
              j <- N.nat$b.yr==b & N.nat$age==a + 1 & N.nat$month==months[1]
              k <- N.nat$b.yr==b & N.nat$age==a     & N.nat$month==months[m+1]

              N.nat$v[i] <- v$mort.rate.v[v$age==a & v$month==months[m]]
              
              if(months[m] == mat){
                  N.nat$N.n[i] <- (N.nat$N.n[j] + N.nat$M[i]) / ((1 - N.nat$v[i]) * (1 - N.nat$i.est[i]))
                  N.nat$I[i]   <-  N.nat$N.n[i] * N.nat$i.est[i]
                  N.nat$V[i]   <-  N.nat$N.n[i] * (1 - N.nat$i.est[i]) * N.nat$v[i]
              }

              if(months[m] != mat){
                  N.nat$N.n[i] <- N.nat$N.n[k] / ((1 - N.nat$v[i]) * (1 - N.nat$i.est[i]))
                  N.nat$I[i]   <- N.nat$N.n[i] * N.nat$i.est[i]
                  N.nat$V[i]   <- N.nat$N.n[i] * (1 - N.nat$i.est[i]) * (N.nat$v[i])
              }
          }
      }
  }
      
  N.nat <- N.nat[N.nat$age <= max(age),] #remove rows for fish greater than the max age

  # Estimate maturation rates.
  # --------------------------

  E.nat <- N.nat[N.nat$month==mat & N.nat$b.yr %in% b.y.co,] 
  E.nat$e <- E.nat$M / (E.nat$N.n * (1 - E.nat$i.est) * (1 - E.nat$v))
      
  if(any(is.nan(E.nat$e))) # Change NAN maturation rates to 1 and give user warning
         warning( c( "For brood year(s) ", paste(unique(E.nat$b.yr[ is.nan(E.nat$e) ]), collapse = ' '),
                    "\n", "Ages(s) ", paste(sort(unique(E.nat$age[ is.nan(E.nat$e) ])), collapse = ' '),
                    "\n", "maturation rate set to 1", "\n" ) )

  E.nat$e[is.nan(E.nat$e)] <- 1

      
  # Reconstruction of incomplete broods.
  # ====================================
  # Allows for a maximum of three incomplete broods    

  # Calculate average maturation rates for complete broods
  Avg.e <- aggregate( e ~ age, data=E.nat[E.nat$b.yr %in% b.y.co,], FUN=mean)
  
  if(length(b.y.in) > 0){
      for (b in 1:length(b.y.in) ){
          for (a in rev(age)[-(1:b)] ){
              for (m in length(months):1){
                  
                  i <- N.nat$b.yr==b.y.in[b] & N.nat$age==a     & N.nat$month==months[m]
                  j <- N.nat$b.yr==b.y.in[b] & N.nat$age==a + 1 & N.nat$month==months[1]
                  k <- N.nat$b.yr==b.y.in[b] & N.nat$age==a     & N.nat$month==months[m+1]
                  
                  N.nat$v[i] <- v$mort.rate.v[v$age==a & v$month==months[m]] #natural mortality rate
                  
                                        # compute abundance, impacts, and natural mortality at
                                        # the end of age [max(age)-1] for the first incomplete brood.
                                        # use average maturation rates of age [max(age)-1]
                  if(a == (max(age)-1) & b == 1 & months[m] == mat){
                      e.m.1 <- Avg.e$e[Avg.e$age == (max(age) - 1)]
                      N.nat$N.n[i] <- (N.nat$M[i] / e.m.1) / ((1 - N.nat$v[i]) * (1 - N.nat$i.est[i]))
                      N.nat$I[i]   <-  N.nat$N.n[i] * N.nat$i.est[i]
                      N.nat$V[i]   <-  N.nat$N.n[i] * (1 - N.nat$i.est[i]) * (N.nat$v[i])
                  }

                                        # compute abundance, impacts, and natural mortality at
                                        # the end of age [max(age)-2] for the second incomplete brood.
                                        # use average maturation rates of age [max(age)-2]
                  if(a == (max(age)-2) & b == 2 & months[m] == mat){
                      e.m.2 <- Avg.e$e[Avg.e$age == (max(age) - 2)]
                      N.nat$N.n[i] <- (N.nat$M[i] / e.m.2) / ((1 - N.nat$v[i]) * (1 - N.nat$i.est[i]))
                      N.nat$I[i]   <-  N.nat$N.n[i] * N.nat$i.est[i]
                      N.nat$V[i]   <-  N.nat$N.n[i] * (1 - N.nat$i.est[i]) * (N.nat$v[i])
                  }
                  
                                        # compute abundance, impacts, and natural mortality
                                        # at the end of age [max(age)-3] for the third incomplete brood.
                                        # use average maturation rates of age [max(age)-3]
                  if(a == (max(age)-3) & b == 3 & months[m] == mat){
                      e.m.3 <- Avg.e$e[Avg.e$age == (max(age) - 3)]
                      N.nat$N.n[i] <- (N.nat$M[i] / e.m.3) / ((1 - N.nat$v[i]) * (1 - N.nat$i.est[i]))
                      N.nat$I[i]   <-  N.nat$N.n[i] * N.nat$i.est[i]
                      N.nat$V[i]   <-  N.nat$N.n[i] * (1 - N.nat$i.est[i]) * (N.nat$v[i])
                  }

              # compute abundance, impacts, and natural mortality for the month
              #of maturation for age < max age
              if(months[m] == mat & a < max(rev(age)[-(1:b)])){
                  N.nat$N.n[i] <- (N.nat$N.n[j] + N.nat$M[i]) / ((1 - N.nat$v[i]) * (1 - N.nat$i.est[i]))
                  N.nat$I[i]   <-  N.nat$N.n[i] * N.nat$i.est[i] 		
                  N.nat$V[i]   <-  N.nat$N.n[i] * (1 - N.nat$i.est[i]) * (N.nat$v[i])
              }

              # compute abundance, impacts, and natural mortality for all other months
              if(months[m] != mat){
                  N.nat$N.n[i] <- N.nat$N.n[k] / ((1 - N.nat$v[i]) * (1 - N.nat$i.est[i]))
                  N.nat$I[i]   <- N.nat$N.n[i] * N.nat$i.est[i]
                  N.nat$V[i]   <- N.nat$N.n[i] * (1 - N.nat$i.est[i]) * (N.nat$v[i])
              }
              }
          }
      }
  }


  # Remove unobserved data (i.e., ages from incomplete broods that have yet to return).
  # -----------------------------------------------------------------------------------

  N.nat <- N.nat[!is.na(N.nat$N.n),]


  # Estimate maturation rates.
  # --------------------------
 
  E.nat <- N.nat[N.nat$month==mat,]  # replace E with updated info on incomplete cohorts

  E.nat$e <- E.nat$M / (E.nat$N.n - E.nat$I - E.nat$V)

  E.nat$e[is.nan(E.nat$e)] <- 1
      

  # Calculate stratum specific contact, harvest, release, dropoff, and impact rates.
  # --------------------------------------------------------------------------------

  Z.nat <- merge(x=Z.nat, y=N.nat[, c("c.yr", "b.yr", "age", "month", "N.n")], all.x=TRUE) 
                                                # Keep all rows in Z.nat

  Z.nat$C   <-  Z.nat$c.est * Z.nat$N.n
  Z.nat$H.o <-  Z.nat$C * Z.nat$plegal
  Z.nat$S   <- (Z.nat$C - Z.nat$H.o) * Z.nat$mort.rate.s
  Z.nat$D   <-  Z.nat$C * d.o
  Z.nat$I   <-  Z.nat$H.o + Z.nat$S + Z.nat$D
 
  # If N.n = 0, the following are NaN values
  Z.nat$h <- Z.nat$H.o / Z.nat$N.n
  Z.nat$c <- Z.nat$C   / Z.nat$N.n
  Z.nat$s <- Z.nat$S   / Z.nat$N.n
  Z.nat$d <- Z.nat$D   / Z.nat$N.n
  Z.nat$i <- Z.nat$I   / Z.nat$N.n 


  # Estimate annual impact rates and maturation rates.
  # --------------------------------------------------

  A.nat <- aggregate(cbind(C, H.o, I) ~ b.yr + age, data=Z.nat, FUN=sum)
  A.nat[is.na(A.nat)] <- 0
  A.nat$N.n <- NA

  for(i in 1:nrow(A.nat)){
      ii <- N.nat$b.yr == A.nat$b.yr[i] & N.nat$age == A.nat$age[i] & N.nat$month == months[1]
      A.nat$N.n[i] <- N.nat$N.n[ii]
  }

  colnames(A.nat)[colnames(A.nat) == c("N.n")] <- "N" # change column names

  # contact, harvest, and impact rates
  A.nat$c <- A.nat$C   / A.nat$N
  A.nat$h <- A.nat$H.o / A.nat$N
  A.nat$i <- A.nat$I   / A.nat$N

  # Change row and column order for output.
  # ---------------------------------------      
  N.nat <- N.nat[order(N.nat$b.yr, N.nat$age, match(N.nat$month, months)), 
                 c("b.yr", "c.yr", "age", "month", "N.n", "I", "V", "M", "W", "R")]


  # Output.
  # -------

  # save annual rates 
  sink(paste(out.dir, "A.nat.dat", sep="/"))
  print(A.nat, row.names = F)  
  sink()

  # save monthly abundances 
  sink(paste(out.dir, "N.nat.dat", sep="/"))
  print(N.nat, row.names = F)  
  sink()

  # save stratum specific, monthly rates 
  sink(paste(out.dir, "Z.nat.dat", sep="/"))
  print(Z.nat, row.names = F)  
  sink()

  # save maturation rates 
  sink(paste(out.dir, "E.nat.dat", sep="/"))
  print(E.nat, row.names = F)  
  sink()
      
 }

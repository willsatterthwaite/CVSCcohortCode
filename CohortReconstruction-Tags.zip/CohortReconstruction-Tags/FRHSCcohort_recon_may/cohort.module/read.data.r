# =============================================================================
read.data <- function(par, data){

    # Read parameters.
    # ----------------

    b.y.co <- scan(par$b.y.co        , quiet=T                ) 
    b.y.in <- scan(par$b.y.in        , quiet=T                ) 
       age <- scan(par$age           , quiet=T                )
       mat <- scan(par$mat           , quiet=T                )
         L <- read.table(par$l       , header=T, as.is=T      )  
       d.o <- scan(par$d.o           , quiet=T                )
       d.r <- scan(par$d.r           , quiet=T                )
     ext.s <- scan(par$ext.s         , what="logical", quiet=T) 
    
    if (ext.s) s <- read.table(par$s , header=T, as.is=T)

       def.s <- read.table(par$def.s   , header=T, as.is=T      ) 
           v <- read.table(par$v       , header=T, as.is=T      )
     E.codes <- scan(par$E.codes       , quiet=T                )
    Hr.codes <- scan(par$Hr.codes      , quiet=T                )
    Ho.codes <- scan(par$Ho.codes      , quiet=T                )
         nat <- scan(par$nat           , what="logical", quiet=T)
    

    # Set up biological year.
    # -----------------------
    ifelse(mat==12, months <- 1:12, months <- c( ((mat+1) : 12), (1:mat)) )
     
    # All broods.
    # -----------
    b.y <- sort(c(b.y.co, b.y.in))

    # Releases.
    # ---------
    X <- read.table(data$r, header=T, as.is=T) #b.yr, type, type.labels, N  
    X <- X[(X$b.yr <= max(b.y) & X$b.yr >= min(b.y)),] #remove brood years
                                                       #not being reconstructed
    
    types <- sort(unique(X$type, na.rm=T)) #identify types to be reconstructed

    # Ocean harvest and cwt recoveries.
    # ---------------------------------
    Z <- read.table(data$ho, header=T, as.is=T)
    colnames(Z)[colnames(Z) %in% c("N", "n.tag")] <- c("H.o", "n.tag.Ho") 

    Z <- Z[(Z$b.yr <= max(b.y) & Z$b.yr >= min(b.y)),]#remove brood years
                                                      #not being reconstructed
    Z <- get.Age(Z, mat) #add column for age

    Z <- Z[(Z$age <= max(age) & Z$age >= min(age)) ,] #remove ages not
                                                      #being reconstructed

    # River harvest and cwt recoveries.
    # ---------------------------------
    Y <- read.table(data$hr, header=T, as.is=T) 
    colnames(Y)[colnames(Y) %in% c("N.stray", "n.tag.stray")] <-
        c("H.r.stray", "n.tag.Hr.stray")
    colnames(Y)[colnames(Y) %in% c("N", "n.tag")] <-
        c("H.r", "n.tag.Hr")
    
    Y <- Y[(Y$b.yr <= max(b.y) & Y$b.yr >= min(b.y)),] #remove brood years
                                                       #not being reconstructed
    Y$age <- Y$c.yr - Y$b.yr #add column for age
    
    Y <- Y[(Y$age <= max(age) & Y$age >= min(age)) ,] #remove ages not
                                                      #being reconstructed

    #dataframe with all combinations of brood years, ages, types, and Hr codes
    Hr <- expand.grid(b.yr = b.y, age = age, type = types, code = Hr.codes)

    #merge: right outer join
    Hr <- merge(x=Y[,colnames(Y)!="c.yr"],
                y=Hr, by=c("b.yr", "age", "type", "code"),
                all.y=TRUE) 
         #note: if all.y= TRUE, then extra rows will be added to the output
    
    #assign zeros to NA values of H.r and n.tag.Hr 
    Hr[is.na(Hr)] <- 0  

    #sum river harvest and tag returns over river harvest codes
    Hr.tot <- aggregate(cbind(H.r, n.tag.Hr,H.r.stray, n.tag.Hr.stray) ~ 
                            b.yr + age + type, data=Hr, FUN=sum,
                        na.action=NULL)

    # Escapement and cwt recoveries.
    # ------------------------------
    W <- read.table( data$e, header=T, as.is=T )  
    colnames(W)[colnames(W) %in% c("N", "n.tag")] <- c("E", "n.tag.E") 
    colnames(W)[colnames(W) %in% c("N.stray", "n.tag.stray")] <-
        c("E.stray", "n.tag.E.stray") 
                    
    W <- W[(W$b.yr <= max(b.y) & W$b.yr >= min(b.y)),] #remove brood years
                                                       #not being reconstructed
    W$age <- W$c.yr - W$b.yr #add column for age

    W <- W[(W$age <= max(age) & W$age >= min(age)) ,] #remove ages not
                                                      #being reconstructed

    #dataframe with all combinations of brood years, ages, types, and E codes
    E <- expand.grid(b.yr = b.y, age = age, type = types,  code = E.codes)

    # merge: right outer join
    E <- merge(x=W[ , colnames(W)!="c.yr"],
               y=E, by=c("b.yr", "age", "type", "code"),
               all.y=TRUE) 
	#note: if all.y= TRUE, then extra rows will be added to the output 

    # assign zeros to NA values of E and n.tag.E 
    E[is.na(E)] <- 0  

    #sum spawners and tag returns over escapement codes
    E.tot <- aggregate(cbind(E, n.tag.E, E.stray, n.tag.E.stray) ~
                           b.yr + age + type, data=E, FUN=sum,
                       na.rm=na.pass)

    # Merge spawners and river harvest.
    # ---------------------------------
    R.hat <- merge(E.tot, Hr.tot, by= c("b.yr", "age", "type"), all=TRUE) 

    # Total hatchery strays (W).
    # --------------------------
    R.hat$W <- rowSums(cbind(R.hat$H.r.stray, R.hat$E.stray), na.rm=TRUE)  
    R.hat$n.tag.tot.W <- rowSums(cbind(R.hat$n.tag.Hr.stray,
                                       R.hat$n.tag.E.stray), na.rm=TRUE)    

    # Total natural-origin ocean escapement (river mouth return).
    # -----------------------------------------------------------
    if( nat ){
  	R.nat <- read.table(data$nat, header=T, as.is=T)  # b.yr, c.yr, N

        R.nat <- R.nat[(R.nat$b.yr <= max(b.y) & R.nat$b.yr >= min(b.y)),]
                              # remove brood years not being reconstructed
        
  	R.nat$age <- R.nat$c.yr - R.nat$b.yr # add column for age

        R.nat <- R.nat[(R.nat$age <= max(age) & R.nat$age >= min(age)) ,]
                                                          #remove ages not
                                                          #being reconstructed

        R.nat <- R.nat[(R.nat$age >= min(age)),] # remove any age-1 escapement
                       
        # produce a dataframe with all combinations of brood years, ages
        df <- expand.grid(b.yr = b.y, age = age)

  	#right outer join
        R.nat <- merge(x=R.nat[,colnames(R.nat)!="c.yr"],
                       y=df, by=c("b.yr", "age"),
                       all.y=TRUE) 
            #note: if all.y= TRUE, then extra rows will be added to the output 

        # assign zeros to NA values of R.nat 
        R.nat[is.na(R.nat)] <- 0
    }else{
        R.nat <- NULL
    }
        
       
# Proportion legal size.
# ----------------------
    Z <- merge(x=Z, y=L, by = c("age","month"), all.x=TRUE) 
    
    Z$plegal <- 1 - pnorm(Z$sl, mean=Z$mean, sd=Z$sd)
    
    if (any(Z$sl==0, na.rm=T)){ Z$plegal[Z$sl == 0] = 1.0 }
                        # This applies to fisheries with no size limit

    if(any(is.na( Z$plegal[Z$H.o > 0 ])))
        warning( "plegal=NA where harvest > 0 on at least one occasion" )

    
# Release mortality rate.
# -----------------------
    if(ext.s){
  	Z <- merge(x=Z, y=s,
                   by = c("c.yr", "fishery", "area", "month"),
                   all.x=TRUE) 

  	Z.print <- unique(Z[is.na(Z$mort.rate.s),
                            c('c.yr', 'month', 'area', 'fishery')])

  	if(any(is.na(Z$mort.rate.s))){
		warning(c( "The following strata are identified in the RMPC data but are not included in release.mort.rate.par file, therefore default release mortality rates are assumed.
					", "\n",
				 
                          paste(capture.output(print(Z.print,
                                                     row.names = F,
                                                     col.names=F)),
                                collapse = "\n"), "\n" ))
            }

      
  	i <- match(Z$fishery[is.na(Z$mort.rate.s)], def.s$fishery)
                            #fill in NAs with default release mortality rates

  	Z$mort.rate.s[is.na(Z$mort.rate.s)] <- def.s$mort.rate.s[i]            
        
    }else{
        
  	i <- match(Z$fishery, def.s$fishery)
                            # assign all to default release mortality rates
        
  	Z$mort.rate.s <- def.s$mort.rate.s[i]     	 
    }

# Output.
# -------
    list(      X = X,
               Z = Z,
           R.hat = R.hat,
           R.nat = R.nat,
               v = v,
             d.o = d.o,
             d.r = d.r,
             age = age,
             b.y = b.y,
          b.y.in = b.y.in,
	  b.y.co = b.y.co,
             mat = mat,
           types = types,
          months = months,
	     nat = nat)  
 
}

# ==============================================================================


#######################################
### Spiral graphs #####################
#######################################
library(spiralize)
library(dplyr)


#######
#set working directory as appropriate
#setwd("D:/Central Valley spring run Chinook/Spiral graphs/") 
#######




#######################################
#######     Butte Creek      ##########
#######################################
### BCW return timing distribution 
#BCW return from february to june, peaking in april
#BCW primarily return at age 3, but also return at age 4 and occasionally age 2
Months<-c(1,2,2.5,3,3.5,4,4.5,5,5.5,6,7,8,9,10,11,12) #All months from Jan-Dec, with greater resolution from Feb - May
Magnitude<-c(0,.2,.4,.5,.75,1,1,.7,.4,.2,0,0,0,0,0,0) 
spawning<-as.data.frame(cbind(rep(2:4, each =16), rep(Months, 3), rep(Magnitude, 3), rep(c(.1,1,.5), each = 16)))
colnames(spawning)<-c("Year","Month", "Spawning", "Maturation.rate")
spawning$Age<-spawning$Year*12+spawning$Month-3 #how many months old they are, assuming April birthday
spawning<-spawning[-c(46:48),] #removing extra months from plot

#all dates is a data frame with all the months a fish are in the ocean. Age is by RY-BY, with Ages switching over January 1
alldates<-as.data.frame(cbind(rep(1998:2007, each= 48),
                            rep(rep(2:5, each=12),10) ,
                            rep(1:12,40)))
colnames(alldates)<-c("b.yr","Age", "month")

dat<-read.csv("BCW.Z.csv") #reading in fishing impact data
dat<-dat %>%
  mutate(Age = c.yr-b.yr) %>%
  group_by(Age, month, b.yr, c.yr, age) %>% #lower case age is the age assigned based on April 1 birthday; upper case Age is RY-BY
  summarise(Impact = sum(I)) 
dat<-left_join(alldates,dat)
dat<-dat %>%
  mutate(Age = Age*12+month-3) %>%
  select(b.yr, Age, month, Impact)
dat[is.na(dat)]<-0

dat<-dat %>%
  #Earliest birthday is April 1
  #So fish a fish after two years Apr is 25 months old
  group_by(Age) %>%
  summarise(Avg_Imp = mean(Impact))

dat$prop<-dat$Avg_Imp/13 #scaled by upper limit


spiral_initialize(xlim = c(22,55), start = 90, period = 12, clockwise = TRUE, polar_lines = TRUE, polar_lines_by = 30,
                  polar_lines_gp = gpar(col = c("darkgoldenrod2","#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080"), 
                                        lty = 1,
                                        lwd = c(4,rep(1,11))))
spiral_track(height = 1, background = FALSE)

spiral_polygon(x=c(spawning$Age, rev(spawning$Age)),
               y=c(spawning$Spawning*spawning$Maturation.rate*.9, rep(0,45)),
               gp = gpar(fill="lightsalmon2"))

dat3<-dat %>%
  filter(Age < 37)
dat4<-dat %>%
  filter(Age < 49 & Age > 36)
dat5<-dat %>%
  filter(Age < 55 & Age > 48)


spiral_bars(dat3$Age+.5, dat3$prop*.7,  gp = gpar(fill="#5B8FB9",alpha = .5))
spiral_bars(dat4$Age+.5, dat4$prop*.7,  gp = gpar(fill="#301E67",alpha = .5))
spiral_bars(dat5$Age+.5, dat5$prop*.7,  gp = gpar(fill="#03001C",alpha = 1))

spiral_text(x=28 , y=.25, text="Ocean Age 3",facing = "curved_inside", just = "right", gp=gpar(cex=1.3))
spiral_text(x=39 , y=.2, text="Ocean Age 4",facing = "curved_inside", just = "right", gp=gpar(cex=1.7))
spiral_text(x=52 , y=.2, text="Ocean Age 5",facing = "curved_inside", just = "right", gp=gpar(cex=1.4))

#Spawners
spiral_text(x=23.8 , y=.3, text="Age 2 Spawners",facing = "curved_inside", just = "right",gp=gpar(cex=1.3))
spiral_text(x=36, y=.3, text="Age 3 Spawners",facing = "curved_inside", just = "right", gp=gpar(cex=1.7))
spiral_text(x=48.4 , y=.3, text="Age 4 Spawners", facing = "curved_inside", just = "right", gp=gpar(cex=1.3))



#Months
spiral_text(x=46.4 , y=1.4, text="Jan", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=47.4, y=1.4, text="Feb",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=48.4 , y=1.4, text="Mar", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=49.4 , y=1.5, text="Apr", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=50.4 , y=1.5, text="May", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=51.4 , y=1.4, text="Jun", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=52.4 , y=1.2, text="Jul", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=53.4 , y=.9, text="Aug",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=54.4 , y=.8, text="Sep",  facing = "curved_inside", just = "right", gp=gpar(cex=1.2))
spiral_text(x=55.4 , y=.7, text="Oct",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=56.4 , y=.7, text="Nov",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=57.4 , y=.6, text="Dec", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
#######################################
####     Feather River Hatchery   #####
#######################################
### FRH return timing distribution 
#FRH return from mid-march to july, peaking in mid-may early june
#BCW primarily return at age 3, but also return at age 4, occasionally age 2, and rarely age 5
Months<-c(1,2,3,3.5,4,4.5,5,5.5,6,6.5,7,7.5,8,9,10,11,12) #All months from Jan-Dec, with greater resolution from Feb - May
Magnitude<-c(0,0,0,.1,.2,.5,.75,1,1,.7,.4,.1,0,0,0,0,0) 
spawning<-as.data.frame(cbind(rep(2:5, each =17), rep(Months, 4), rep(Magnitude, 4), rep(c(.1,1,.5,.05), each = 17)))
colnames(spawning)<-c("Year","Month", "Spawning", "Maturation.rate")
spawning$Age<-spawning$Year*12+spawning$Month-3 #how many months old they are, assuming April birthday (even though sometimes in June and July)
spawning<-spawning[-c(65:68),] #removing extra months from plot


#FRH spawn at age 2,3,4,5
#Fishing happens after age 5 spawn but no age 6 spawners, last time cohort is encountered in fishing
alldates<-as.data.frame(cbind(rep(1998:2016, each= 48),
                            rep(rep(2:5, each=12),19) ,
                            rep(1:12,19*4)))

colnames(alldates)<-c("b.yr","Age", "month")
setwd("D:/Central Valley spring run Chinook/Spiral graphs/")
dat<-read.csv("FRH.Z.csv")
dat<-dat %>%
  mutate(Age = c.yr-b.yr) %>%
  group_by(Age, month, b.yr, c.yr, age) %>%
  summarise(Impact = sum(I)) 
dat<-left_join(alldates,dat)
dat<-dat %>%
  mutate(Age = Age*12+month-3) %>%
  select(b.yr, Age, month, Impact)
dat[is.na(dat)]<-0

dat<-dat %>%
  #Earliest birthday is April 1
  #So fish a fish after two years Apr is 25 months old
  group_by(Age) %>%
  summarise(Avg_Imp = mean(Impact))

dat$prop<-dat$Avg_Imp/900


#April 1 birthday
spiral_initialize(xlim = c(22,55), start = 90, period = 12, clockwise = TRUE, polar_lines = TRUE, polar_lines_by = 30,
                  polar_lines_gp = gpar(col = c("darkgoldenrod2","#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080"), 
                                        lty = 1,
                                        lwd = c(4,rep(1,11))))
spiral_track(height = 1, background = FALSE)


spiral_polygon(x=c(spawning$Age, rev(spawning$Age)),
               y=c(spawning$Spawning*spawning$Maturation.rate*.9, rep(0,64)),
               gp = gpar(fill="lightsalmon2"))

dat2<-dat %>%
  filter(Age < 25)
dat3<-dat %>%
  filter(Age < 37 & Age > 24)
dat4<-dat %>%
  filter(Age < 49 & Age > 36)
dat5<-dat %>%
  filter(Age < 61 & Age > 48)
dat6<-dat %>%
  filter(Age > 60 & Age < 65)

spiral_bars(dat2$Age+.5, dat2$prop*.8,  gp = gpar(fill="#B6EADA",alpha = .8))
spiral_bars(dat3$Age+.5, dat3$prop*.8,  gp = gpar(fill="#5B8FB9",alpha = .5))
spiral_bars(dat4$Age+.5, dat4$prop*.8,  gp = gpar(fill="#301E67",alpha = .5))
spiral_bars(dat5$Age+.5, dat5$prop*.8,  gp = gpar( fill="#03001C",alpha = .8))
spiral_bars(dat6$Age+.5, dat6$prop*.8,  gp = gpar( fill="#03001C",alpha = .8))

#Age
spiral_text(x=27 , y=.25, text="Ocean Age 3",facing = "curved_inside", just = "right", gp=gpar(cex=1.3))
spiral_text(x=39 , y=.2, text="Ocean Age 4",facing = "curved_inside", just = "right", gp=gpar(cex=1.7))
spiral_text(x=49.5 , y=.2, text="Ocean Age 5",facing = "curved_inside", just = "right", gp=gpar(cex=1.3))
spiral_text(x=61.3 , y=.2, text="Ocean Age 6",facing = "curved_inside", just = "right", gp=gpar(cex=1.1))
#Spawners
spiral_text(x=26 , y=.5, text="Age 2 Spawners",facing = "curved_inside", just = "right",gp=gpar(cex=1.3))
spiral_text(x=38, y=.7, text="Age 3 Spawners",facing = "curved_inside", just = "right", gp=gpar(cex=1.7))
spiral_text(x=50 , y=.6, text="Age 4 Spawners", facing = "curved_inside", just = "right", gp=gpar(cex=1.3))
spiral_text(x=62 , y=.2, text="Age 5 Spawners", facing = "curved_inside", just = "right", gp=gpar(cex=1.1))



#Months
spiral_text(x=46.4 , y=1.4, text="Jan", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=47.4, y=1.4, text="Feb",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=48.4 , y=1.4, text="Mar", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=49.4 , y=1.5, text="Apr", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=50.4 , y=1.5, text="May", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=51.4 , y=1.4, text="Jun", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=52.4 , y=1.2, text="Jul", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=53.4 , y=.9, text="Aug",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=54.4 , y=.8, text="Sep",  facing = "curved_inside", just = "right", gp=gpar(cex=1.2))
spiral_text(x=55.4 , y=.7, text="Oct",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=56.4 , y=.7, text="Nov",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=57.4 , y=.6, text="Dec", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))


##############################
#Jun 1 birthday
spiral_initialize(xlim = c(22,55), start = 90, period = 12, clockwise = TRUE, polar_lines = TRUE, polar_lines_by = 30,
                  polar_lines_gp = gpar(col = c("#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080","darkgoldenrod2","#808080"), 
                                        lty = 1,
                                        lwd = c(rep(1,10),4,1)))
spiral_track(height = 1, background = FALSE)


spiral_polygon(x=c(spawning$Age, rev(spawning$Age)),
               y=c(spawning$Spawning*spawning$Maturation.rate*.9, rep(0,64)),
               gp = gpar(fill="lightsalmon2"))

dat2<-dat %>%
  filter(Age < 27)
dat3<-dat %>%
  filter(Age < 39 & Age > 26)
dat4<-dat %>%
  filter(Age < 51 & Age > 38)
dat5<-dat %>%
  filter(Age < 63 & Age > 50)
dat6<-dat %>%
  filter(Age > 62 & Age < 65)

spiral_bars(dat2$Age+.5, dat2$prop*.8,  gp = gpar(fill="#B6EADA",alpha = .8))
spiral_bars(dat3$Age+.5, dat3$prop*.8,  gp = gpar(fill="#5B8FB9",alpha = .5))
spiral_bars(dat4$Age+.5, dat4$prop*.8,  gp = gpar(fill="#301E67",alpha = .5))
spiral_bars(dat5$Age+.5, dat5$prop*.8,  gp = gpar( fill="#03001C",alpha = .8))
spiral_bars(dat6$Age+.5, dat6$prop*.8,  gp = gpar( fill="#03001C",alpha = .8))

#Age
spiral_text(x=24.5 , y=.24, text="Ocean Age 2",facing = "curved_inside", just = "right", gp=gpar(cex=1.2))
spiral_text(x=27.2 , y=.25, text="Ocean Age 3",facing = "curved_inside", just = "right", gp=gpar(cex=1.3))
spiral_text(x=39.3 , y=.2, text="Ocean Age 4",facing = "curved_inside", just = "right", gp=gpar(cex=1.7))
spiral_text(x=51.1 , y=.2, text="Ocean Age 5",facing = "curved_inside", just = "right", gp=gpar(cex=1.3))
spiral_text(x=63.1 , y=.2, text="Ocean Age 6",facing = "curved_inside", just = "right", gp=gpar(cex=1.1))

#Spawners
spiral_text(x=26 , y=.5, text="Age 2 Spawners",facing = "curved_inside", just = "right",gp=gpar(cex=1.3))
spiral_text(x=38, y=.7, text="Age 3 Spawners",facing = "curved_inside", just = "right", gp=gpar(cex=1.7))
spiral_text(x=50 , y=.6, text="Age 4 Spawners", facing = "curved_inside", just = "right", gp=gpar(cex=1.3))
spiral_text(x=62 , y=.2, text="Age 5 Spawners", facing = "curved_inside", just = "right", gp=gpar(cex=1.1))

#Months
spiral_text(x=46.4 , y=1.4, text="Jan", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=47.4, y=1.4, text="Feb",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=48.4 , y=1.4, text="Mar", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=49.4 , y=1.5, text="Apr", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=50.4 , y=1.5, text="May", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=51.4 , y=1.4, text="Jun", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=52.4 , y=1.2, text="Jul", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=53.4 , y=.9, text="Aug",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=54.4 , y=.8, text="Sep",  facing = "curved_inside", just = "right", gp=gpar(cex=1.2))
spiral_text(x=55.4 , y=.7, text="Oct",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=56.4 , y=.7, text="Nov",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=57.4 , y=.6, text="Dec", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
# spiral_text(x=62.6 , y=2.5, text="Jun 1 Birthday", facing = "downward", just = "right",gp=gpar(cex=1.3))

##############################
#July 1 birthday
spiral_initialize(xlim = c(22,55), start = 90, period = 12, clockwise = TRUE, polar_lines = TRUE, polar_lines_by = 30,
                  polar_lines_gp = gpar(col = c("#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080","#808080","darkgoldenrod2","#808080","#808080"), 
                                        lty = 1,
                                        lwd = c(rep(1,9),4,1,1)))
spiral_track(height = 1, background = FALSE)


spiral_polygon(x=c(spawning$Age, rev(spawning$Age)),
               y=c(spawning$Spawning*spawning$Maturation.rate*.9, rep(0,64)),
               gp = gpar(fill="lightsalmon2"))
dat2<-dat %>%
  filter(Age < 28)
dat3<-dat %>%
  filter(Age < 40 & Age > 27)
dat4<-dat %>%
  filter(Age < 52 & Age > 39)
dat5<-dat %>%
  filter(Age < 64 & Age > 51)


spiral_bars(dat2$Age+.5, dat2$prop*.8,  gp = gpar(fill="#B6EADA",alpha = .8))
spiral_bars(dat3$Age+.5, dat3$prop*.8,  gp = gpar(fill="#5B8FB9",alpha = .5))
spiral_bars(dat4$Age+.5, dat4$prop*.8,  gp = gpar(fill="#301E67",alpha = .5))
spiral_bars(dat5$Age+.5, dat5$prop*.8,  gp = gpar( fill="#03001C",alpha = .8))

#Age

spiral_text(x=25 , y=.25, text="Ocean Age 2",facing = "curved_inside", just = "right", gp=gpar(cex=1.2))
spiral_text(x=28.2 , y=.25, text="Ocean Age 3",facing = "curved_inside", just = "right", gp=gpar(cex=1.3))
spiral_text(x=40.3 , y=.2, text="Ocean Age 4",facing = "curved_inside", just = "right", gp=gpar(cex=1.7))
spiral_text(x=52.1 , y=.2, text="Ocean Age 5",facing = "curved_inside", just = "right", gp=gpar(cex=1.3))
#Spawners

#Spawners
spiral_text(x=26 , y=.5, text="Age 2 Spawners",facing = "curved_inside", just = "right",gp=gpar(cex=1.3))
spiral_text(x=38, y=.7, text="Age 3 Spawners",facing = "curved_inside", just = "right", gp=gpar(cex=1.7))
spiral_text(x=50.2 , y=.6, text="Age 4 Spawners", facing = "curved_inside", just = "right", gp=gpar(cex=1.3))
spiral_text(x=62.2 , y=.2, text="Age 5 Spawners", facing = "curved_inside", just = "right", gp=gpar(cex=1.1))

#Months
spiral_text(x=46.4 , y=1.4, text="Jan", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=47.4, y=1.4, text="Feb",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=48.4 , y=1.4, text="Mar", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=49.4 , y=1.5, text="Apr", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=50.4 , y=1.5, text="May", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=51.4 , y=1.4, text="Jun", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=52.4 , y=1.2, text="Jul", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=53.4 , y=.9, text="Aug",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=54.4 , y=.8, text="Sep",  facing = "curved_inside", just = "right", gp=gpar(cex=1.2))
spiral_text(x=55.4 , y=.7, text="Oct",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=56.4 , y=.7, text="Nov",  facing = "curved_inside", just = "right",gp=gpar(cex=1.2))
spiral_text(x=57.4 , y=.6, text="Dec", facing = "curved_inside", just = "right",gp=gpar(cex=1.2))

##############################

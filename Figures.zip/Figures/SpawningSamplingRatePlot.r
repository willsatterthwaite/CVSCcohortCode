dat=read.csv("FRHrecoveries.csv")
spawn.dat=dat[dat$fishery==54,]
run.years=sort(unique(spawn.dat$run_year))
expansions=NA*run.years
for (i in 1:length(expansions))
{
	exp.this.year=spawn.dat$estimated_number[spawn.dat$run_year==run.years[i]]
	expansions[i]=mean(exp.this.year,na.rm=TRUE)
}

pdf("cvsc_cohort_FigC2-FRHSCsamplerate.pdf",width=9,height=4)
par(mar=c(4,4.5,2,2),cex.lab=1.2,cex.axis=1.1)
plot(run.years,1/expansions,xlab="Return Year",ylab="Spawning Grounds Sampling Rate",las=1,xlim=c(2000,2019))
dev.off()
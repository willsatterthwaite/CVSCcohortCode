dat=read.csv("CVSCcohortDat.csv")
cfm.yrs=c(9:18) #to pull out just the most reliable FRH brood years
#Plotting color scheme and line types
#dark green = Butte Creek wild spring
#brown = Feather River hatchery spring
#red = Sacramento fall
#blue = winter run
#lwd=1 younger age
#lwd=2 older age
#lty=2 dubious brood years [pre-CFM for FRH, scales for BCW]
#lty=3 sensitivities (different birth dates, Kimura-Chikuni)


library(Hmisc)
#plot core BCWSC CWT results, with uncertainty
unc.dat=read.csv("UncertaintySummaryBCWSC.csv")
pdf("cvsc_cohort_Fig2-BCWSCcore.pdf",width=9,height=6)
par(mfrow=c(2,1),mar=c(4,4.5,2,2),cex.lab=1.2,cex.axis=1.1)
plot(unc.dat$brood_year,unc.dat$Imp3,col="dark green",xlab="Brood Year",ylab="Impact Rate",main="a) Ocean Impact Rates",ylim=c(0,1),las=1)
axis(side=1,at=c(1998:2015),labels=FALSE)
errbar(x=unc.dat$brood_year,y=unc.dat$Imp3,yplus=unc.dat$Imp3Upper,yminus=unc.dat$Imp3Lower,col="dark green",pch=1,errbar.col="dark green",add=TRUE)
errbar(x=unc.dat$brood_year+0.05,y=unc.dat$Imp4,yplus=unc.dat$Imp4Upper,yminus=unc.dat$Imp4Lower,col="dark green",pch=19,errbar.col="dark green",add=TRUE)
text(2002.5,0.2,"age-3",col="dark green")
text(2001,0.8,"age-4",col="dark green")
plot(unc.dat$brood_year,unc.dat$Mat3,col="dark green",xlab="Brood Year",ylab="Maturation Rate",main="b) Maturation Rates",ylim=c(0,1),pch=19,las=1)
axis(side=1,at=c(1998:2015),labels=FALSE)
errbar(x=unc.dat$brood_year,y=unc.dat$Mat3,yplus=unc.dat$Mat3Upper,yminus=unc.dat$Mat3Lower,col="dark green",pch=19,errbar.col="dark green",add=TRUE)
text(2003.5,.4,"age-3",col="dark green")
errbar(x=unc.dat$brood_year,y=unc.dat$Mat2,yplus=unc.dat$Mat2Upper,yminus=unc.dat$Mat2Lower,col="dark green",pch=4,errbar.col="dark green",add=TRUE)
text(1999,0.07,"age-2",col="dark green")
errbar(x=unc.dat$brood_year+0.1,y=unc.dat$Mat4,yplus=unc.dat$Mat4Upper,yminus=unc.dat$Mat4Lower,col="dark green",pch=1,errbar.col="dark green",add=TRUE)
text(2003,0.9,"age-4",col="dark green")
dev.off()

#Plot FRH CFM year results
pdf("cvsc_cohort_Fig3-FRHSCcore.pdf",width=9,height=9)
par(mfrow=c(2,2),mar=c(4,4.5,2,2),cex.lab=1.2,cex.axis=1.1)
plot(dat$BroodYr[cfm.yrs],dat$imp3.frt.may.base[cfm.yrs],xlim=c(2006,2015),ylim=c(0,1),type="l",col="brown",lwd=1,xlab="Brood Year",ylab="Ocean Impact Rate",main="a) Ocean Impact Rates",las=1)
axis(side=1,at=c(1998:2015),labels=FALSE) #add ticks for each brood year even if not all labeled
text(2009,0.13,"FRH age-3",col="brown")
lines(dat$BroodYr[cfm.yrs],dat$imp4.frt.may.base[cfm.yrs],col="brown",lwd=2)
text(2012.5,0.4,"FRH age-4",col="brown")
lines(dat$BroodYr[cfm.yrs],dat$imp3.frt.mar[cfm.yrs],lty=3,col="brown")
lines(dat$BroodYr[cfm.yrs],dat$imp3.frt.jun[cfm.yrs],lty=2,col="brown")
lines(dat$BroodYr[cfm.yrs],dat$imp4.frt.mar[cfm.yrs],lty=3,col="brown",lwd=2)
lines(dat$BroodYr[cfm.yrs],dat$imp4.frt.jun[cfm.yrs],lty=2,col="brown",lwd=2)

plot(dat$BroodYr[cfm.yrs],dat$mat2.frt.may.base[cfm.yrs],xlim=c(2006,2015),ylim=c(0,1),type="l",col="brown",lwd=1,xlab="Brood Year",ylab="Maturation Rate",main="b) Maturation Rates",las=1)
axis(side=1,at=c(1998:2015),labels=FALSE) #add ticks for each brood year even if not all labeled
text(2008,0.15,"FRH age-2",col="brown")
lines(dat$BroodYr[cfm.yrs],dat$mat3.frt.may.base[cfm.yrs],col="brown",lwd=2)
text(2014,0.7,"FRH age-3",col="brown")
lines(dat$BroodYr[cfm.yrs],dat$mat2.frt.mar[cfm.yrs],lty=3,col="brown")
lines(dat$BroodYr[cfm.yrs],dat$mat2.frt.jun[cfm.yrs],lty=2,col="brown")
lines(dat$BroodYr[cfm.yrs],dat$mat3.frt.mar[cfm.yrs],lty=3,col="brown",lwd=2)
lines(dat$BroodYr[cfm.yrs],dat$mat3.frt.jun[cfm.yrs],lty=2,col="brown",lwd=2)

plot(dat$BroodYr[cfm.yrs],dat$srr.frt.may.base[cfm.yrs],xlim=c(2006,2015),ylim=c(0,1),type="l",col="brown",lwd=2,xlab="Brood Year",ylab="SRR",main="c) Spawner Reduction Rates",las=1)
axis(side=1,at=c(1998:2015),labels=FALSE) #add ticks for each brood year even if not all labeled
text(2011,0.45,"FRH",col="brown")
lines(dat$BroodYr[cfm.yrs],dat$srr.frt.mar[cfm.yrs],lty=3,col="brown",lwd=2)
lines(dat$BroodYr[cfm.yrs],dat$srr.frt.jun[cfm.yrs],lty=2,col="brown",lwd=2)

plot(dat$BroodYr[cfm.yrs],dat$els.frt.may.base[cfm.yrs],xlim=c(2006,2015),ylim=c(0,0.1),type="l",col="brown",lwd=2,xlab="Brood Year",ylab="ELS",main="d) Early Life Survival",las=1)
axis(side=1,at=c(1998:2015),labels=FALSE) #add ticks for each brood year even if not all labeled
text(2011,0.05,"FRH",col="brown")
lines(dat$BroodYr[cfm.yrs],dat$els.frt.mar[cfm.yrs],lty=3,col="brown",lwd=2)
lines(dat$BroodYr[cfm.yrs],dat$els.frt.jun[cfm.yrs],lty=2,col="brown",lwd=2)
dev.off()





#Plot BCW tag results along with FRH base case CFM years, plus BCW scales and non-CFM FRH tags, overlay fall and winter
pdf("cvsc_cohort_Fig4-Comparison.pdf",width=9,height=9)
par(mfrow=c(4,1),mar=c(4,4.5,2,2),cex.lab=1.2,cex.axis=1.1)
plot(dat$BroodYr[cfm.yrs],dat$imp3.frt.may.base[cfm.yrs],xlim=c(1998,2015),ylim=c(0,1),type="l",col="brown",lwd=1,xlab="Brood Year",ylab="Ocean Impact Rate",main="a) Ocean Impact Rates",las=1)
axis(side=1,at=c(1998:2015),labels=FALSE) #add ticks for each brood year even if not all labeled
text(2009,0.15,"FRH age-3",col="brown")
lines(dat$BroodYr[cfm.yrs],dat$imp4.frt.may.base[cfm.yrs],col="brown",lwd=2)
text(2011,0.6,"FRH age-4",col="brown")
lines(dat$BroodYr,dat$imp3.bct,col="dark green")
lines(dat$BroodYr[1:9],dat$imp4.bct[1:9],col="dark green",lwd=2) #don't plot BY2007 estimate - based on just 1 tag
text(2000,0.85,"BCW age-4",col="dark green")
text(2000,0.12,"BCW age-3",col="dark green")
lines(dat$BroodYr,dat$imp3.frt.may.base,col="brown",lty=2)
lines(dat$BroodYr,dat$imp4.frt.may.base,col="brown",lty=2,lwd=2)
lines(dat$BroodYr,dat$SI.oh.matched,lwd=2,col="red")
text(2014,0.58,"SRFC OH",col="red")
lines(dat$BroodYr,dat$SRWC.i3,col="blue")
text(1999,0.295,"SRWC i3",col="blue")
#lines(dat$BroodYr,dat$SRWC.i4,col="blue",lwd=2)

plot(dat$BroodYr[cfm.yrs],dat$mat2.frt.may.base[cfm.yrs],xlim=c(1998,2015),ylim=c(0,1),type="l",col="brown",lwd=1,xlab="Brood Year",ylab="Maturation Rate",main="b) Maturation Rates",las=1)
axis(side=1,at=c(1998:2015),labels=FALSE) #add ticks for each brood year even if not all labeled
text(2008,0.15,"FRH age-2",col="brown")
lines(dat$BroodYr[cfm.yrs],dat$mat3.frt.may.base[cfm.yrs],col="brown",lwd=2)
text(2014,0.7,"FRH age-3",col="brown")
lines(dat$BroodYr,dat$mat2.bct,col="dark green")
lines(dat$BroodYr,dat$mat3.bct,col="dark green",lwd=2)
text(2002,0.08,"BCW age-2",col="dark green")
text(2000,0.6,"BCW age-3",col="dark green")
lines(dat$BroodYr,dat$mat2.frt.may.base,col="brown",lty=2)
lines(dat$BroodYr,dat$mat3.frt.may.base,col="brown",lty=2,lwd=2)
lines(dat$BroodYr,dat$mat3.bcs.raw,col="dark green",lty=2,lwd=2)
lines(dat$BroodYr,dat$mat3.bcs.adj,col="dark green",lty=3,lwd=2)
lines(dat$BroodYr,dat$SRWC.mat3,lwd=2,col="blue")
text(2000,0.87,"SRWC age-3",col="blue")

plot(dat$BroodYr[cfm.yrs],dat$srr.frt.may.base[cfm.yrs],xlim=c(1998,2015),ylim=c(0,1),type="l",col="brown",lwd=2,xlab="Brood Year",ylab="SRR",main="c) Spawner Reduction Rates",las=1)
axis(side=1,at=c(1998:2015),labels=FALSE) #add ticks for each brood year even if not all labeled
text(2011,0.45,"FRH",col="brown")
lines(dat$BroodYr,dat$srr.bct,col="dark green",lwd=2)
text(2000.8,0.5,"BCW",col="dark green")
lines(dat$BroodYr,dat$srr.frt.may.base,lwd=2,lty=2,col="brown")

plot(dat$BroodYr[cfm.yrs],dat$els.frt.may.base[cfm.yrs],xlim=c(1998,2015),ylim=c(0,.11),type="l",col="brown",lwd=2,xlab="Brood Year",ylab="ELS",main="d) Early Life Survival",las=1)
axis(side=1,at=c(1998:2015),labels=FALSE) #add ticks for each brood year even if not all labeled
text(2012,0.04,"FRH",col="brown")
lines(dat$BroodYr,dat$els.bct,col="dark green",lwd=2)
text(2002,0.006,"BCW",col="dark green")
lines(dat$BroodYr,dat$els.frt.may.base,lwd=2,lty=2,col="brown")
lines(dat$BroodYr,dat$SRWC.els,lwd=2,col="blue")
text(2010,0.003,"SRWC",col="blue")

dev.off()





#plot contributions of nonlanded fishing mortality
nonlanded.dat=read.csv("NonlandedContributions.csv")
pdf("cvsc_cohort_Fig5-Nonlanded.pdf",width=9,height=6)
par(mfrow=c(2,1),mar=c(4,4.5,2,2),cex.lab=1.2,cex.axis=1.1)
plot(nonlanded.dat$BroodYear,100*nonlanded.dat$FRHSC.i3.nl,xlim=c(1998,2015),ylim=c(0,60),type="l",col="brown",lwd=1,xlab="Brood Year",ylab="Nonlanded Contribution (%)",main="a) Proportional contribution to ocean impact rates",las=1)
axis(side=1,at=c(1998:2015),labels=FALSE) #add ticks for each brood year even if not all labeled
text(2009,015,"FRH age-3",col="brown")
lines(nonlanded.dat$BroodYear,100*nonlanded.dat$BCWSC.i3.nl,lwd=1,col="dark green")
text(2005.5,45,"BCW age-3",col="dark green")
lines(nonlanded.dat$BroodYear,100*nonlanded.dat$FRHSC.i4.nl,lwd=2,col="brown")
points(nonlanded.dat$BroodYear[18],100*nonlanded.dat$FRHSC.i4.nl[18],col="brown",pch=20)
text(2010,1,"FRH age-4",col="brown")
lines(nonlanded.dat$BroodYear,100*nonlanded.dat$BCWSC.i4.nl,lwd=2,col="dark green")
text(2004.5,0,"BCW age-4",col="dark green")

plot(nonlanded.dat$BroodYear,100*nonlanded.dat$FRHSC.srr.nl,xlim=c(1998,2015),ylim=c(0,80),type="l",col="brown",lwd=2,xlab="Brood Year",ylab="Nonlanded Contribution (%)",main="b) Proportional contribution to spawner reduction rate",las=1)
axis(side=1,at=c(1998:2015),labels=FALSE) #add ticks for each brood year even if not all labeled
lines(nonlanded.dat$BroodYear,100*nonlanded.dat$BCWSC.srr.nl,lwd=2,col="dark green")
text(2005,30,"BCW",col="dark green")
text(2012,40,"FRH",col="brown")
dev.off()





#plot FRHSC uncertainty
unc.frh.dat=read.csv("UncertaintySummaryFRHSC.csv")
pdf("cvsc_cohort_FigC1-FRHSCboot.pdf",width=9,height=6)
par(mfrow=c(2,1),mar=c(4,4.5,2,2),cex.lab=1.2,cex.axis=1.1)
plot(unc.frh.dat$brood_year,unc.frh.dat$Imp3,col="brown",xlab="Brood Year",ylab="Impact Rate",main="a) Ocean Impact Rates",ylim=c(0,1),las=1)
axis(side=1,at=c(1998:2015),labels=FALSE)
errbar(x=unc.frh.dat$brood_year,y=unc.frh.dat$Imp3,yplus=unc.frh.dat$Imp3Upper,yminus=unc.frh.dat$Imp3Lower,col="brown",pch=1,errbar.col="brown",add=TRUE)
errbar(x=unc.frh.dat$brood_year+0.05,y=unc.frh.dat$Imp4,yplus=unc.frh.dat$Imp4Upper,yminus=unc.frh.dat$Imp4Lower,col="brown",pch=19,errbar.col="brown",add=TRUE)
text(2001,0.1,"age-3",col="brown")
text(2003,0.8,"age-4",col="brown")
plot(unc.frh.dat$brood_year,unc.frh.dat$Mat3,col="brown",xlab="Brood Year",ylab="Maturation Rate",main="b) Maturation Rates",ylim=c(0,1),pch=19,las=1)
axis(side=1,at=c(1998:2015),labels=FALSE)
errbar(x=unc.frh.dat$brood_year,y=unc.frh.dat$Mat3,yplus=unc.frh.dat$Mat3Upper,yminus=unc.frh.dat$Mat3Lower,col="brown",pch=19,errbar.col="brown",add=TRUE)
text(2006,0.55,"age-3",col="brown")
errbar(x=unc.frh.dat$brood_year,y=unc.frh.dat$Mat2,yplus=unc.frh.dat$Mat2Upper,yminus=unc.frh.dat$Mat2Lower,col="brown",pch=4,errbar.col="brown",add=TRUE)
text(2002,0.11,"age-2",col="brown")
errbar(x=unc.frh.dat$brood_year+0.1,y=unc.frh.dat$Mat4,yplus=unc.frh.dat$Mat4Upper,yminus=unc.frh.dat$Mat4Lower,col="brown",pch=1,errbar.col="brown",add=TRUE)
text(1999,0.75,"age-4",col="brown")
dev.off()






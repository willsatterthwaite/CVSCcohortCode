min.age=2
max.age=4
num.ages=max.age-min.age+1 #3     ###If any of these change, need to recode!

options(scipen=9999) #suppress scientific notation


valid.mat=as.matrix(read.csv("ValidationMatrixEvenYearsPooled.csv",header=FALSE))
raw.age.structure=array(NA,(1+num.ages))
raw.age.structure[1]=1
scale.counts=read.csv("OddYearRawScales.csv")
raw.age.structure[2:4]=as.numeric(scale.counts)

adj.age.structure=raw.age.structure


raw.2s=raw.age.structure[2]
raw.3s=raw.age.structure[3]
raw.4s=raw.age.structure[4]

read.ages=c(raw.2s,raw.3s,raw.4s)
raw.N=raw.2s+raw.3s+raw.4s
p.raw=c(raw.2s,raw.3s,raw.4s)/raw.N
source("KimuraChikuni.r")
p.adj=p.hat.final



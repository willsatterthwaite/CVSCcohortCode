scale.dat=read.csv("ButteScalesKnown.csv")
#trim out un-assigned ages (age 0)
good.scale.dat=scale.dat[scale.dat$ReadAge>0,]
min.age=min(good.scale.dat$ReadAge) #2
max.age=max(good.scale.dat$ReadAge) #4
num.ages=max.age-min.age+1 #3     ###If any of these change, need to recode!

options(scipen=9999) #suppress scientific notation


valid.mat=as.matrix(read.csv("ValidationMatrixAllYearsPooled.csv",header=FALSE))

return.years=c(min(good.scale.dat$ReturnYear):max(good.scale.dat$ReturnYear)) #realizing this will add a row with NAs - but we want NAs to factor into inability to estimate age structure for some brood years as appropriate later

raw.age.structure=array(NA,c(length(return.years),(1+num.ages)))
raw.age.structure[,1]=return.years

adj.age.structure=raw.age.structure

for (year.step in 1:(length(return.years)))
{#loop over return years
	raw.2s=sum(good.scale.dat$ReadAge[good.scale.dat$ReturnYear==return.years[year.step]]==2)
	raw.3s=sum(good.scale.dat$ReadAge[good.scale.dat$ReturnYear==return.years[year.step]]==3)
	raw.4s=sum(good.scale.dat$ReadAge[good.scale.dat$ReturnYear==return.years[year.step]]==4)
	raw.N=raw.2s+raw.3s+raw.4s
	raw.age.structure[year.step,2:4]=c(raw.2s,raw.3s,raw.4s)/raw.N
	read.ages=c(raw.2s,raw.3s,raw.4s)
	source("KimuraChikuni.r")
	adj.age.structure[year.step,2:4]=p.hat.final	
}#loop over return years


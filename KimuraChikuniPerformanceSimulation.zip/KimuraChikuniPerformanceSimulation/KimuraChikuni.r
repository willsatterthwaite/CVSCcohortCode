# validation matrix passed from calling function valid.mat=as.matrix(read.csv("ValidationMatrix.csv",header=FALSE))
# read ages passed from calling fucntion read.ages=as.matrix(read.csv("ReadAges.csv",header=FALSE))

#ages are indexed by j
#recall that j=1 indexes the youngest age, which is generally 2

a=length(read.ages)
n=a #"length" categories are really scale-read ages

#initialize p.hat - estimated proportion in each age class j
p.hat=array(1/a,a)

#observed distribution of "length" at age
q=array(NA,c(n,a))
for (i in 1:n)
{
	for (j in 1:a)
	{
		q[i,j]=as.numeric(valid.mat[i,j])
	}
}
for (j in 1:a) q[,j]=q[,j]/colSums(q)[j]

#observed "length" distribution
f=array(NA,n)
for (i in 1:n)
{
	f[i]=as.numeric(read.ages[i])
}
f.bar=f
for (i in 1:n) f.bar[i]=f[i]/sum(f)

#IALK algorithm
max.iterations=500
p.chain=array(NA,c(max.iterations,a))
l.hat=array(NA,n) #placeholder, l.hat updated within loop
Pr.hat=array(NA,c(n,a)) #placeholder, Pr.hat updated within loop
iteration=1
bailout=0

while ((iteration+bailout)<(max.iterations+1))
{#iteration while loop
	p.chain[iteration,]=p.hat
	for (i in 1:n)
	{#loop over n
		l.hat[i]=sum(p.hat*q[i,])
	}#loop over n
	p.hat.new=p.hat
	p.hat.old=p.hat
	for (j in 1:a)
	{#loop over a
		cum.sum=0
		for (i in 1:n)
		{#loop over n
			cum.sum=cum.sum+f.bar[i]*p.hat[j]*q[i,j]/l.hat[i]
		}#loop over n
		p.hat.new[j]=cum.sum
	}#loop over a
	p.hat=p.hat.new
	iteration=iteration+1
	if (max(abs(p.hat.new-p.hat.old),na.rm=TRUE)<0.00005) bailout=max.iterations
}#iteration while loop

p.hat.final=p.hat
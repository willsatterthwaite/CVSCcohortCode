get.Age <- function( Z, mat ) {

    # calculate age and days since birthday this way if contacted
    # between Jan and maturation month
    Z$age <- Z$c.yr - Z$b.yr

    # calculate age this way if contacted after mature month but before Jan
    Z$age[Z$month > mat] <- Z$c.yr[Z$month > mat] - Z$b.yr[Z$month > mat] + 1
    
    return(Z)
    
}

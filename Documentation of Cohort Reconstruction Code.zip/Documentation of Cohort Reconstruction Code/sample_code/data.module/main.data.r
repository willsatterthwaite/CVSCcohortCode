# This program controls the running of the modules that produce the input
# files for the cohort reconstructions.  The individual modules include:
# read.data.r - reads CWT release and recovery data downloaded from RMPC
# user.inputs.r - reads user-defined inputs 
# release.r - summarizes release data and assigns release "types"
#             (if applicable)
# escapement.r - summarizes escapement data
# river.harvest.r - summarizes river harvest data
# ocean.harvest.r - summarizes ocean harvest data
# type.r - defines "types" of releases that will be reconstructed separately
#          (if applicable)
# exp.factor.r - allows for external CWT expansion factors to be used
# stray.r - defines strays (fish that return to areas outside of
#           natal river or basin)
# sl.r - allows for external minimum size limits in ocean fisheries to be used
# space.r - allows for spatially-stratified cohort reconstructions
# 
# ==============================================================================
# Set working directory

#rm(list = ls(all = TRUE))

#setwd(w.dir)

library(lubridate)  # Package for dealing with dates
options(warning.length=8170)  # To print verbose warnings

# runtime
ptm <- proc.time()

# capture all the warnings to a file.
zz <- file("warnings.data.module.txt", open = "wt")
sink(file=zz, type = "message")

# ==============================================================================
# Sub-directories

data.mod.dir <- "data.module"                # subdirectory for data module

core.data.dir <- "data.module/core.data"     # subdirectory for CWT and
                                             # natural-origin return data

other.data.dir <- "data.module/other.data"   # subdirectory for 'other' data

x.fun.dir <- "data.module/extra.functions"   # subdirectory for functions
                                             # defining additional structure for
                                             # cohort reconstruction

input.dir <- "user.inputs"                   # subdirectory for user-defined
                                             # inputs

out.dir <- "cohort.module/cohort.input.data" # subdirectory to store output
                                             # files used as inputs for cohort
                                             # reconstructions  

# ==============================================================================
# Source programs

source(paste(data.mod.dir,     "read.data.r", sep="/"))
source(paste(data.mod.dir,   "user.inputs.r", sep="/"))
source(paste(data.mod.dir,       "release.r", sep="/"))
source(paste(data.mod.dir,    "escapement.r", sep="/"))
source(paste(data.mod.dir, "river.harvest.r", sep="/"))
source(paste(data.mod.dir, "ocean.harvest.r", sep="/"))

source(paste(x.fun.dir,       "type.r", sep="/"))
source(paste(x.fun.dir, "exp.factor.r", sep="/"))
source(paste(x.fun.dir,      "space.r", sep="/"))
source(paste(x.fun.dir,         "sl.r", sep="/"))
source(paste(x.fun.dir,      "stray.r", sep="/"))

# ==============================================================================
# Run programs

# ------------------------------------------------------------------------------
# user-defined inputs

U <- user.inputs(input.dir)

# ------------------------------------------------------------------------------
# read CWT data and send natural-origin return data to cohort.input.data

# specify paths
releases   <- paste(core.data.dir, "releases.csv"          , sep="/")
recoveries <- paste(core.data.dir, "recoveries.csv"        , sep="/") 
nat.origin <- paste(core.data.dir, "nat.origin.returns.dat", sep="/") 

Z <- read.data(releases, recoveries, nat.origin, out.dir, U$natural.origin)

# ------------------------------------------------------------------------------
# releases

R <- release(Z$rel, U$multiple.types, U$tagged.only, out.dir)

# ------------------------------------------------------------------------------
# escapement

E <- escapement(Z$rec, R$r, R$type, R$n.type, R$l.type, R$type.lab, R$p,
                R$broods, R$n.broods, U$minage, U$maxage, U$E.codes, 
                U$external.exp.factor, U$strays, U$tagged.only, other.data.dir,
                out.dir)

# ------------------------------------------------------------------------------
# river harvest

#first check - were there any river fishery recoveries
if (sum(Z$rec["fishery"]==46)>0)
{
H.r <- river.harvest(Z$rec, R$r, R$type, R$n.type, R$l.type, R$type.lab, R$p,
                     R$broods, R$n.broods, U$minage, U$maxage, U$Hr.codes,
                     U$external.exp.factor, U$strays, U$tagged.only,
                     other.data.dir, out.dir)
}
if (sum(Z$rec["fishery"]==46)==0)
{#create empty river.harvest.dat file 
sink(paste(out.dir, "river.harvest.dat", sep="/"))
    print(c("b.yr","c.yr","code","type","N","n.tag","N.stray","n.tag.stray"), row.names = F)  
    sink()
}


# ------------------------------------------------------------------------------
# ocean harvest

H.o <- ocean.harvest(Z$rec, R$r, R$type, R$n.type, R$l.type, R$type.lab, R$p,
                     R$broods, R$n.broods, U$minage, U$maxage, U$Ho.codes,
                     U$external.exp.factor, U$spatial, U$tagged.only,
                     U$external.sl, U$sl.default, other.data.dir, out.dir)

# ==============================================================================

print(proc.time() - ptm)













# Function that inserts minimum size limits from external regulations data
# into the Ho.dat file

sl <- function(x, other.data.dir){

    z <- read.table(paste(other.data.dir, "size.limits.dat", sep="/"),
                    header=T, sep="") # file with minimum size limit information
  
    for(i in 1:nrow(z)){
        ii <- x$c.yr == z$c.yr[i] & x$fishery == z$fishery[i] &
              x$area == z$area[i] & x$month == z$month[i]

        x$sl[ii] <- z$limit[i]
    }

    x.tmp <- merge( x, z, all.x = TRUE) 
    
    x.print <- unique( x.tmp[ is.na( x.tmp$limit),
                             c('c.yr', 'month', 'area', 'fishery')] )

    if( any( is.na( x.tmp$limit) ) ){
        warning(c("The following strata are identified in the RMPC data but are not included in size.limits.dat file, therefore default size limits are assumed.", "\n",
        paste(capture.output(print(x.print, row.names = F, col.names=F)),
                        collapse = "\n")))

    }
    
    return(x)
}

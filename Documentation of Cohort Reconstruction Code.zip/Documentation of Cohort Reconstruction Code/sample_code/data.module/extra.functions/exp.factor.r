# Function that allows for externally-estimated CWT sample expansion factors
# to be incorporated into escapement, river harvest, and/or ocean harvest
# estimates. Expansion factors are linked to CWT recoveries by the catch
# sample ID (CSID).

exp.factor <- function(x, other.data.dir){

    # Read file with externally-derived CWT sample expansion factors
    # linked by catch sample ID  
    z <- read.table(paste(other.data.dir, "external.exp.factors.txt", sep="/"),
                    header=T, sep="") 
                                        
    for(i in 1:nrow(z)){
        ii <- x$csid == z$csid[i]# Assign sample expansion factors 
        x$estnum[ii] <- z$xfact[i]
    }
    
    return(x)
}

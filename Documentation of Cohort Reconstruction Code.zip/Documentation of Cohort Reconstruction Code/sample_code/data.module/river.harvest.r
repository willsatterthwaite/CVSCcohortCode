# River harvest module.  Combines information from the release file with the
# recovery file to produce river.harvest.dat.

# ==============================================================================

#rec <- Z$rec
#r <- R$r 
#type <- R$type
#n.type <- R$n.type
#l.type <- R$l.type
#type.lab <- R$type.lab
#p <- R$p
#broods <- R$broods
#n.broods <- R$n.broods
#minage <- U$minage
#maxage <- U$maxage
#Hr.codes <- U$Hr.codes
#external.exp.factor <- U$external.exp.factor
#strays <- U$strays
#tagged.only <- U$tagged.only 

river.harvest <- function(rec, r, type, n.type, l.type, type.lab, p, broods,
                          n.broods, minage, maxage, Hr.codes,
                          external.exp.factor, strays, tagged.only,
                          other.data.dir, out.dir){


    Hr.rec <- rec[(rec$fishery %in% Hr.codes),]  #confine recoveries to
                                               #river harvest
  
    hr <- data.frame(CWTcode = Hr.rec$tag_code, #tag code
                    b.yr = rep(NA, length=nrow(Hr.rec)),#brood year
                    c.yr = as.numeric(Hr.rec$run_year), #recovery year
                 fishery = Hr.rec$fishery,              #recovery sector
                  locode = Hr.rec$recovery_location_code, #recovery location
                    site = as.character(Hr.rec$sampling_site),#sample site
	           stray = rep(FALSE, length=nrow(Hr.rec)),#stray classification
                    csid = Hr.rec$catch_sample_id,      #catch sample ID
                  estnum = as.numeric(Hr.rec$estimated_number), #sample exp factor
                  prdfct = rep(NA, length=nrow(Hr.rec)),#production factor
                    type = rep(NA, length=nrow(Hr.rec)),#type 
                type.lab = rep(NA, length=nrow(Hr.rec)),#type label
        stringsAsFactors = FALSE)          

    cwt.codes <- unique(r$CWTcode)      #identify all CWT codes

    for(i in cwt.codes){
        b.yr.tmp <- r$b.yr[r$CWTcode==i] #link brood year with CWT code
        p.tmp <- p[r$CWTcode==i] #link production expansion with CWT code
        type.tmp <- type[r$CWTcode==i] #link type with CWT code
        type.lab.tmp <- type.lab[r$CWTcode==i] #link type label with CWT code
        
        if(sum(r$CWTcode==i) > 0){
            hr$b.yr[hr$CWTcode==i] <- b.yr.tmp #assign brood year
            hr$prdfct[hr$CWTcode==i] <- p.tmp  #assign producton factor
            hr$type[hr$CWTcode==i] <- type.tmp #assign type 
            hr$type.lab[hr$CWTcode==i] <- type.lab.tmp #assign type label 
        }
    }

    if(external.exp.factor == TRUE){
        hr <- exp.factor(hr, other.data.dir)
    }

    # Check for inconsistencies
    NA_exp <- which(is.na(hr$estnum))
    if(length(NA_exp)>0){ #warn user if any expansion factors are NA         
  	warning(paste( "There are", length(NA_exp), 
        "RMPC data records that do not have a sample expansion factor", "\n")) 
    }

    if(tagged.only==FALSE){
        NA_prd <- which( is.na(hr$prdfct))
        if(length(NA_prd)>0){#warn if any production expansion factors are NA
  		  warning(c(  paste( "There are", length(NA_prd),  
	       "RMPC data records that do not have a production factor"), "\n",
		"These are associated with the following tag codes: ",
                            paste(hr$CWTcode[NA_prd], collapse = ' '), "\n" )) 
              }
    }

    if(strays == TRUE){
        hr <- stray(hr, other.data.dir)
    }

    n.Hr.codes <- length(Hr.codes)        #number of river harvest codes 

    max.dat <- max(hr$c.yr - hr$b.yr) # max years for CWT recovery after brood year
    min.dat <- min(hr$c.yr - hr$b.yr) # min years for CWT recovery after brood year
    
    dat.length <- n.broods * (max.dat - min.dat + 1) * n.Hr.codes * n.type
                                        #combination of brood years, 
                                        #recovery calendar years,
                                        #river harvest codes, and types

    rec.yr <- rep(broods, each=((max.dat - min.dat + 1) * n.Hr.codes * n.type)) +
        rep((min.dat:max.dat), each=(n.Hr.codes*n.type), times=n.broods)
                                                #allows recoveries confined to:
                                                #brood year + min(calendar year - brood year)
                                                #brood year + max(calendar year - brood year)

    Hr.dat <- data.frame(b.yr = rep(broods, each=((max.dat - min.dat + 1) * n.Hr.codes*n.type)),
                        c.yr = rec.yr,
                        code = rep(Hr.codes, each=n.type, length.out=dat.length),
                        type = rep(l.type, length.out=dat.length),
                           N = rep(NA, dat.length),
                       n.tag = rep(NA, dat.length),
                     N.stray = rep(NA, dat.length),
                 n.tag.stray = rep(NA, dat.length),
            stringsAsFactors = FALSE)

    for(i in 1:nrow(Hr.dat)){
    	ii <- (hr$b.yr == Hr.dat$b.yr[i] &
                   hr$c.yr == Hr.dat$c.yr[i] &
                       hr$fishery == Hr.dat$code[i] &
                           hr$type == Hr.dat$type[i])
         
    	if(sum(ii) > 0){
            ii.stray <- ii & hr$stray
            ii.natal <- ii & !hr$stray

            if( tagged.only ){
      		Hr.dat$N[i] <- round( sum( hr$estnum[ii.natal], na.rm=T), digits=2) 
      		Hr.dat$n.tag[i] <- sum(ii.natal)
                
      		Hr.dat$N.stray[i] <- round( sum( hr$estnum[ii.stray], na.rm=T), digits=2) 
      		Hr.dat$n.tag.stray[i] <- sum(ii.stray)
                                        #sums sample expansion factor 
                                        #for all recoveries,
                                        #but omits records when either 
                                        #expansion factor is NA
            }else{
      		Hr.dat$N[i] <- round(sum((hr$estnum[ii.natal] * hr$prdfct[ii.natal]),
                                          na.rm=T), digits=2) 
      		Hr.dat$n.tag[i] <- sum(ii.natal)

      		Hr.dat$N.stray[i] <- round(sum((hr$estnum[ii.stray] * hr$prdfct[ii.stray]),
                                               na.rm=T), digits=2) 
      		Hr.dat$n.tag.stray[i] <- sum(ii.stray)
                                        #sums production factor * sample
                                        #expansion factor for all recoveries,
                                        #but omits records when either 
                                        #expansion factor is NA
            }
        }
    }

    Hr.dat <- Hr.dat[!is.na(Hr.dat$N),]   #removes NA records to reduce file size

    # save file of river harvest by brood year, calendar year, RMIS code, and type
    sink(paste(out.dir, "river.harvest.dat", sep="/"))
    print(Hr.dat, row.names = F)  
    sink()

}

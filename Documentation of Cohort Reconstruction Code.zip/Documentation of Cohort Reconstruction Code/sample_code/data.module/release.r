#  Hatchery release module.  Takes release file and summarizes releases across
#  brood years and 'types'.

# ==============================================================================

release <- function(rel, multiple.types, tagged.only, out.dir){
    
    r <- data.frame(CWTcode = rel$tag_code_or_release_id,#tag code
                       b.yr = as.numeric(rel$brood_year),#brood year
                     cwt1mk = rel$cwt_1st_mark,#5000 for CWT+ad-clip 0 or NA for no mark
                      cwt1N = as.numeric(rel$cwt_1st_mark_count),#the number released with CWT+ad-clip(code 5000) corrected for tag loss and mortality
                     cwt2mk = rel$cwt_2nd_mark,#5000 for CWT+ad-clip 0 or NA for no mark
                      cwt2N = as.numeric(rel$cwt_2nd_mark_count),#the number released corresponding to 2mk-code
                   Nocwt1mk = rel$non_cwt_1st_mark,#5000 for ad-cliped no cwt (shed CWT) and 0 for no-ad-clip no cwt
                    Nocwt1N = as.numeric(rel$non_cwt_1st_mark_count),#the number of fish released without cwt for code nocwt1mk
                   Nocwt2mk = rel$non_cwt_2nd_mark,#mark-code 0 for no-ad-clip and no cwt (no mass marking at Coleman)
                    Nocwt2N = as.numeric(rel$non_cwt_2nd_mark_count),#the number of fish released without cwt for code nocwt2mk
		          p = NA,#production expansion factor
		       type = NA,#type
           stringsAsFactors = FALSE)                    

    #remove tag codes with leading !
    i.keep <- which(substr(r$CWTcode,1,1) != "!")
    r <- r[i.keep,]

    #define type vectors  
    if(multiple.types==FALSE){
        n.type      <- 1
        l.type      <- 1
        type.labels <- NA
        type        <- rep( 1, nrow(r))
        type.lab    <- rep(NA, nrow(r))
    }else{
        x           <- types(rel)
        n.type      <- x$n.type
        l.type      <- x$l.type
        type.labels <- x$type.labels
        type        <- x$type
        type.lab    <- x$type.lab
    }
    r$type <- type

    #total releases by CWT code
    R.tot <- rowSums(r[,c("cwt1N","cwt2N","Nocwt1N","Nocwt2N")], na.rm=T)
    
    #p = production multiplier. Ratio of total releases
    #to marked and tagged releases.
    p <-  R.tot / r$cwt1N 
                           
    r$p <- p

    #if only tagged fish to be reconstructed, specify those releases
    if(tagged.only) R.tot <- r$cwt1N
    
    broods <- sort(unique(r$b.yr)) #unique brood years in the release file
    n.broods <- length(broods) #number of unique broods
    
    #set up release output file
    rel.out <- data.frame(       b.yr = rep(broods,       each = n.type),
                                 type = rep(l.type,      times = n.broods),
                          type.labels = rep(type.labels, times = n.broods),
                                    N = rep(NA,         length = n.type*n.broods))
    
    for(i in broods){      #assign total number released by brood year
        for(j in l.type){  #and type to output file 
            ii <- r$b.yr==i & type==j
            if(sum(ii) > 0){
                rel.out[(rel.out$b.yr == i & rel.out$type == j),"N"] <- sum(R.tot[ii])
            }
        }
    }

    #save file of releases by brood year and type
    sink(paste(out.dir, "releases.dat", sep="/"))
    print(rel.out, row.names = F)  
    sink()

    # ----------------------------------------------------------------------------

    list(   r = r,
         type = type,
     type.lab = type.lab,
            p = p,
       broods = broods,
     n.broods = n.broods,
       n.type = n.type,
       l.type = l.type
       )
  
}




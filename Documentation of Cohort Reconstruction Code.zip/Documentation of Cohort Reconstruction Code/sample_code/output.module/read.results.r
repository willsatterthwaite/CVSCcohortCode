# ==============================================================================
read.results <- function(par, data){

# Read parameters.
# ----------------

      b.y.co <- scan(par$b.y.co        , quiet=T          ) 
      b.y.in <- scan(par$b.y.in        , quiet=T          ) 
         age <- scan(par$age           , quiet=T          )
           v <- read.table(par$v       , header=T, as.is=T)
         mat <- scan(par$mat           , quiet=T          )
         nat <- scan(par$nat           , what="logical", quiet=T)

# Set up biological year.
# -----------------------
      ifelse(mat==12, months <- 1:12, months <- c(((mat+1):12), (1:mat)))

# Natural mortality rate.
# ----------------------

    #add age column to natural mortality rate (v) based on mature month   
	v$age <- NA
	v$age[v$month <= mat] <- v$yrs_since_byr[v$month <=mat]
	v$age[v$month > mat] <- v$yrs_since_byr[v$month > mat] + 1
    #remove 'yrs_since_byr' column
	v <- v[ , c("age", "month", "mort.rate.v")]    

     
# All broods.
# -----------
      b.y <- sort(c(b.y.co, b.y.in))

# Read cohort output.
# -------------------
      A <- read.table(results$A, header=T, as.is=TRUE) 
      N <- read.table(results$N, header=T, as.is=TRUE) 
      Z <- read.table(results$Z, header=T, as.is=TRUE) 
      E <- read.table(results$E, header=T, as.is=TRUE)
      X <- read.table(results$X, header=T, as.is=TRUE)
      
      colnames(A)[colnames(A)=="N.h"] <- "N"
      colnames(N)[colnames(N)=="N.h"] <- "N"
      colnames(Z)[colnames(Z)=="N.h"] <- "N"
      colnames(E)[colnames(E)=="N.h"] <- "N"
      colnames(X)[colnames(X)=="N"  ] <- "Rel"
      
      types <- sort(unique(A$type, na.rm=T))#identify types to be reconstructed
      
      if(nat){
          A.nat <- read.table(results$A.nat, header=T, as.is=TRUE) 
          N.nat <- read.table(results$N.nat, header=T, as.is=TRUE) 
          Z.nat <- read.table(results$Z.nat, header=T, as.is=TRUE) 
          E.nat <- read.table(results$E.nat, header=T, as.is=TRUE) 
    
          # Add natural data as natural type
          A.nat$type <- 'Natural'
          N.nat$type <- 'Natural'
          Z.nat$type <- 'Natural'
          E.nat$type <- 'Natural'

          colnames(A.nat)[colnames(A.nat)=="N.n"] <- "N"
          colnames(N.nat)[colnames(N.nat)=="N.n"] <- "N"
          colnames(Z.nat)[colnames(Z.nat)=="N.n"] <- "N"
          colnames(E.nat)[colnames(E.nat)=="N.n"] <- "N"
          
          A <- merge(A, A.nat, all=TRUE)
          N <- merge(N, N.nat, all=TRUE)
          Z <- merge(Z, Z.nat, all=TRUE)
          E <- merge(E, E.nat, all=TRUE)	
      }

# Output.
# -------
    list(      A = A,
               N = N,
               Z = Z,
               E = E,
               X = X,
             age = age,
             b.y = b.y,
          b.y.in = b.y.in,
          b.y.co = b.y.co,
             mat = mat,
               v = v,
           types = types,
          months = months )  
 
  }

# ==============================================================================


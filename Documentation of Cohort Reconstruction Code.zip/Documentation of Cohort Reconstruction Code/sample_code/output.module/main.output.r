# ==============================================================================
# This program controls the production of cohort reconstruction output files.
# The individual modules include:
# read.results.r - reads user inputs and cohort reconstruction results
# output.results.r - calculates spawner reduction rates, produces output files,
# and figures.
#
# ==============================================================================
 
#rm(list = ls(all = TRUE))

# Set working directory.
# ----------------------

#setwd(w.dir)

options(warning.length=8170)  # To print verbose warnings

# Sub-directories.
# ----------------

output.mod.dir <- "output.module"

cohort.output.dir <- "output.module/cohort.output"    # subdirectory for inputs 
						      # from the cohort module

user.input.dir <- "user.inputs"                 # subdirectory for user-defined
                                                # inputs

out.dir <- "output.module/output"               # subdirectory to store output
                                                # files 
 

# Read component programs into memory.
# ------------------------------------

source(paste(output.mod.dir, "read.results.r"   , sep="/"))
source(paste(output.mod.dir, "output.results.r" , sep="/"))


# Increase output file line length.
# ---------------------------------

default.output.file.line.nchar <- getOption("width")
options(width=300)  # reset to 300
options(max.print=10E05) # allows for 10000 rows in output files
options(scipen=10) # suppresses scientific notation


# Specify Input filenames.
# ------------------------
 
# Input parameters:
par <- list( b.y.co = "complete.broods.par",
             b.y.in = "incomplete.broods.par", 
                age = "ages.par",             
                mat = "mature.month.par",     
                  l = "length.at.age.par",    
                d.o = "drop.off.ocean.par",
                d.r = "drop.off.river.par",
                  s = "release.mort.rate.par", 
              def.s = "default.release.mort.rate.par", 
                  v = "natural.mort.rate.par",   
            E.codes = "escapement.codes.par",
           Hr.codes = "river.fishery.codes.par",
           Ho.codes = "ocean.fishery.codes.par",
      	        nat = "natural.origin.par"
              )

# Input results:
results <- list(  A = "A.dat",
                  N = "N.dat", 
                  Z = "Z.dat", 
                  E = "E.dat",
                  X = "X.dat",
 	      A.nat = "A.nat.dat",
	      N.nat = "N.nat.dat", 
	      Z.nat = "Z.nat.dat", 
	      E.nat = "E.nat.dat"
                )

par <- lapply(par, function(i) paste(user.input.dir, i, sep="/" ))
results <- lapply(results, function(i) paste(cohort.output.dir, i, sep="/" ))

# Output:
fo <- list(out.1 = "ocean.details.out",
           out.2 = "reconstruction.out",
           out.3 = "annual.rates.out",  
           out.4 = "srr.out",
           out.5 = "els.out"
           )

fo <- lapply(fo, function(i) paste(out.dir, i, sep="/"))

# Read results and parameters into storage arrays.
# ------------------------------------------------
R.D <- read.results(par, results)  

# Print results.
# --------------
output.results(fo, R.D)

# Reset print options.
# --------------------
options(width=default.output.file.line.nchar)

# ==============================================================================
sink(type = "message")


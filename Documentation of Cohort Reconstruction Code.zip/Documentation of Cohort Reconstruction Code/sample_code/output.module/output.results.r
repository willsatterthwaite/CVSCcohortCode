# ==============================================================================
output.results <- function(fo, R.D){

# Data, parameters, estimates.
# ----------------------------
    months <- R.D$months  
      ages <- R.D$age
         A <- R.D$A
         N <- R.D$N
         Z <- R.D$Z
         E <- R.D$E
         X <- R.D$X
    

# Output file: ocean.details".
# ----------------------------
    sink(fo$out.1)
            
    u <- c("b.yr", "c.yr", "age", "type", "month", "area", "fishery",
           "C", "H.o", "TR", "S", "D", "I", "c", "h", "s", "d", "i" )
   
    u.round.1 <- c("C", "H.o", "S", "D", "I")
   
    u.round.2 <- c("c", "h", "s", "d", "i" )

    Z.out <- Z[order(Z$type, Z$b.yr, match(Z$month, months), Z$fishery),] 
    colnames(Z.out)[ colnames(Z.out) =="n.tag.Ho"] <- "TR"
 
    Z.out[, u.round.1] <- round(Z.out[, u.round.1], digits=2) 
    Z.out[, u.round.2] <- round(Z.out[, u.round.2], digits=4) 

    print( Z.out[, u] , row.names=FALSE) 
    
    sink()

    
# Output file: "reconstruction".
# ------------------------------
    sink(fo$out.2)
    
    u <- c("b.yr","c.yr", "age", "month", "type", "N", "I", "V", "M", "W",
           "R", "H.r", "D.r", "I.r", "E", "n.tag.Hr", "n.tag.E", "n.tag.W")

    u.round <- c("N", "I", "V", "M", "W", "R", "H.r", "D.r", "I.r", "E")
    
    N.out <- N[order(N$type, N$b.yr, N$age, match(N$month, months)),]
    colnames(N.out)[colnames(N.out)=="H"] <- "H.r"
    
    N.out[,u.round] <- round(N.out[,u.round], digits=2) 
    
    print(N.out[,u], row.names=FALSE) 
    
    sink()

    
# Output file: "annual.rates".
# ----------------------------
    sink(fo$out.3)
    
    u <- c("b.yr", "type", "age", "i", "e")
    u.round <- c("i", "e")
    
    A.out <- merge(A, E[,c("b.yr", "type", "age", "e")], all.x=TRUE)
    
    A.out <- A.out[order(A.out$type, A.out$b.yr, A.out$age),]
    
    A.out[,u.round] <- round(A.out[, u.round], digits=4)
    
    print(A.out[, u], row.names=FALSE)  
    
    sink()


# Output file: "srr".
# -------------------
    sink(fo$out.4)
    
    S <- get.SRR(R.D)
    print(S)
    
    sink()

    
# Output file: "els".
# -------------------
    sink(fo$out.5)

    A.tmp <- A[A$age==min(ages), c("b.yr", "type", "age", "N")]

    X.out <- merge(A.tmp, X, by=c("b.yr", "type"), all=T)

    X.out <- X.out[,c("b.yr", "type", "N", "Rel")]

    #abundance at beginning of the minimum age (age-2 usually)
    #divied by the number released
    X.out$els <- round(X.out$N / X.out$Rel, digits=8)

    print(X.out)

    sink()

    
}

# ==============================================================================

  get.SRR <- function(R.D){

# Data, parameters, estimates.
# ----------------------------
      b.y <- R.D$b.y
   b.y.co <- R.D$b.y.co
      mat <- R.D$mat
        v <- R.D$v
      age <- R.D$age
    types <- R.D$types
        N <- R.D$N
        A <- R.D$A
        E <- R.D$E

   

# SRR calc.
# ---------

      A <- merge(A, E[,c("b.yr","type","age","e","M","W","R","E")], all.x=TRUE)

      N.I0 <- A[, c("b.yr","type","age","N","e","M","W","R","E")]

      # calculate escapement absent effects of ocean fisheries
      N.I0$N0 <- NA
      N.I0$E0 <- NA   

      N.I0$N0[N.I0$age==age[1]] <- N.I0$N[N.I0$age==age[1]] #age-2 abundance

      N.I0$E0[N.I0$age==age[1]] <-  N.I0$N0[N.I0$age==age[1]] *
          prod(1 - v$mort.rate.v[v$age==age[1]]) *
              N.I0$e[N.I0$age==age[1]]  #age-2 escapement (absent fisheries)

      for(a in age[-1]){
          for(t in types){
              tf1 <- N.I0$age==(a-1) & N.I0$type==t  & N.I0$b.yr %in% b.y.co
              tf2 <- N.I0$age== a    & N.I0$type==t  & N.I0$b.yr %in% b.y.co

              #calculate yearly abundance absent effects of ocean and river
              #fisheries
              N.I0$N0[tf2] <- N.I0$N0[tf1] *
                  prod(1 - v$mort.rate.v[v$age==(a-1)]) *
                      (1 - N.I0$e[tf1]) 
              
              #calculate escapement absent effects of ocean and river fisheries
              N.I0$E0[tf2] <- N.I0$N0[tf2] * 
                  prod(1 - v$mort.rate.v[v$age==a]) *
                           N.I0$e[tf2] 
          }
      }

      # sum ADULT (> min age [i.e., age-2]) escapement and escapement absent
      # ocean and river fishing over ages
      SRR.df <- aggregate(cbind(E0, E) ~ b.yr + type,
                          data=N.I0,         #[N.I0$age!=min(age),],
                          FUN=sum,           #(if adult SRR desired)
                          na.action=na.pass)
      
      # calculate SRR
      SRR <- (SRR.df$E0 - SRR.df$E) / SRR.df$E0
      
# Output.
# -------
      names( SRR ) <- NULL
      SRR <- round(SRR,4)
      data.frame( b.yr=SRR.df$b.y, type= SRR.df$type, SRR=SRR ) 
      
  }
# ==============================================================================


